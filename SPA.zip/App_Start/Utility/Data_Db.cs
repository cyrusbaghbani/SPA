﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;




/// <summary>
/// Summary description for Data_Db
/// </summary>
/// 
public static class DefualtValue
{
    public static int ZAMAN_TAKHMINI_LIZER = 30;//min
    public static int TIME_TO_SMS_HOURS = 24;//hour



    public static int My_Admin_Role_Id = 1;
}
public static class RoleIds
{
    public static int Administrator = 1;//faghat Sherkat Emonet
    public static int AdminWebSiteIds = 2;//hour
    public static int MonshiIds = 3;
    public static int PersonelIds = 4;


}
public static class VaziatNobatType
{
    public static string DONE_ = "DONE";
    public static string CANCEL_COSTOMER_ = "CANCEL_COSTOMER";
    public static string CANCEL_USER_ = "CANCEL_USER";
    public static string NONE_DONE_ = "NONE_DONE";

}

public static class PishfarzSpa
{

    public static string TelNumber = global::System.Configuration.ConfigurationManager.AppSettings["TelSpaNumber"].ToString();
    public static string Name = "آوا اسپا";
}