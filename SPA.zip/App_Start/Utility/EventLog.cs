﻿using MVC_AVASPA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Web;
using Utility;

namespace MVC_AVASPA.App_Start.Utility
{
    /// <summary>
    ///1    ورود به سیستم    		
    ///2	خروج از سیستم		
    ///3	ذخیره		
    ///4	ویرایش		
    ///5	حذف		
    ///6	ورود ناموفق		
    ///7	پایان یافتن		
    ///8	ارسال پیام کوتاه دستی		
    ///9	ارسال پیام کوتاه از طریق سیستم
    ///10   فراموشی رمز عبور
    /// </summary>
    public static class EventTypeIds
    {

        public static int VorodBSystem
        {
            get
            {
                return 1;
            }
        }
        public static int khorojAzSystem
        {
            get
            {
                return 2;
            }
        }
        public static int SAVE
        {
            get
            {
                return 3;
            }
        }
        public static int EDIT
        {
            get
            {
                return 4;
            }
        }
        public static int DELETE
        {
            get
            {
                return 5;
            }
        }
        public static int VorodNamovafagh
        {
            get
            {
                return 6;
            }
        }
        public static int PayanYaftan
        {
            get
            {
                return 7;
            }
        }
        public static int ErsalPayamKotahDasti
        {
            get
            {
                return 8;
            }
        }
        public static int ErsalPayamKotahSystemi
        {
            get
            {
                return 9;
            }
        }
        public static int Forgotpassword
        {
            get
            {
                return 10;
            }
        }
    }

    public static class EventLog
    {
        private static void Log(string Dsc, int EventTypeIds, int? UserIds)
        {
            try
            {
                dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
                var obj = new Event();
                obj.UID = Guid.NewGuid();
                obj.UserId = UserIds;
                obj.TimePersian = DateShamsi.GetCurrentHour();
                obj.DatePersian = DateShamsi.GetCurrentDate();
                obj.DateTimeEn = DateTime.Now;
                obj.EventTypeId = EventTypeIds;
                obj.DSC = Dsc;
                obj.IP = GET_IP() ;
                obj.NAMEOFPROJECT = "AVASPA";
                dc.Events.InsertOnSubmit(obj);
                dc.SubmitChanges();
            }
            catch
            { }
        }
        private static string GET_IP()
        {
            string IPAddress = "";
            try
            {
                IPHostEntry Host = default(IPHostEntry);
                string Hostname = null;
                Hostname = System.Environment.MachineName;
                Host = Dns.GetHostEntry(Hostname);
                foreach (IPAddress IP in Host.AddressList)
                {
                    if (IP.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        IPAddress = Convert.ToString(IP);
                    }
                }

            }
            catch
            {
                IPAddress = "";
            }
            return IPAddress;
        }
        public static void Loging(string Dsc, int EventTypeIds, int? UserIds)
        {
            try
            {
                (new Thread(() => Log(Dsc, EventTypeIds, UserIds))).Start();
            }
            catch
            { }
        }
    }
}