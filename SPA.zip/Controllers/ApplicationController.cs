﻿
using MVC_AVASPA.App_Start.Utility;
using MVC_AVASPA.Models;
using MVC_AVASPA.Models.Application.Pages;
using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace MVC_AVASPA.Controllers
{
    public class PersonModel
    {
        public string Name = "";
        public string DateTime = "";
    }
    public class ApplicationController : MasterController
    {
        string OldPageIndex
        {
            get
            {
                if (Request.Cookies["SearchuDEX"] != null && Request.Cookies["SearchuDEX"]["PageIndex"] != null)
                {

                    return Request.Cookies["SearchuDEX"]["PageIndex"];
                }

                return "";
            }
            set
            {
                Response.Cookies["SearchuDEX"]["PageIndex"] = value.ToString();
            }
        }

        #region TimeSheet Package

        #region Calender TimeSheet
        private void Display_Table(CalenderTimeSheetModel obj)
        {

            string currentDate = DateShamsi.GetCurrentDate();
            string Date = EmoNetUtility.GetQueryString("date", (string)RouteData.Values["id"]);
            Date = DateShamsi.GetShamsiDateString(Date + "/" + "01");
            if (Date == "")
                Date = currentDate.Split('/')[0] + "/" + currentDate.Split('/')[1] + "/" + "01";

            obj.lbl_Title_Month_Year = "&nbsp; " + DateShamsi.GetShamsiMonth(int.Parse(Date.Split('/')[1])) + "&nbsp;" + Date.Split('/')[0];

            CreateCalender(int.Parse(Date.Split('/')[0]), int.Parse(Date.Split('/')[1]), currentDate, Date, obj);

            return;
        }

        private void CreateCalender(int Year, int Month, string currentDate, string date, CalenderTimeSheetModel obj)
        {

            var person = dc.users.FirstOrDefault(s => s.Id.ToString() == obj.personIds);
            string personname = person == null ? "همه پرسنل" : person.FullName;
            int currentNextmont = (Month + 1) > 12 ? 1 : (Month + 1);
            DayOfWeek Week = DayOfWeek.Friday;

            obj.TBODY_Table_Calender = "";

            int date_mont = int.Parse(date.Split('/')[1]);

            while (int.Parse(date.Split('/')[1]) == Month)
            {
                obj.TBODY_Table_Calender += "  <tr>    ";


                ////شنبه
                bool IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Saturday, obj.personIds, personname);
                date = Week == DayOfWeek.Saturday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;

                ////یک شنبه
                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Sunday, obj.personIds, personname);
                date = Week == DayOfWeek.Sunday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;
                ////دو شنبه
                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Monday, obj.personIds, personname);
                date = Week == DayOfWeek.Monday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;
                ////سه شنبه
                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Tuesday, obj.personIds, personname);
                date = Week == DayOfWeek.Tuesday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;
                ////چهار شنبه
                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Wednesday, obj.personIds, personname);
                date = Week == DayOfWeek.Wednesday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;
                ////پنج شنبه
                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Thursday, obj.personIds, personname);
                date = Week == DayOfWeek.Thursday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;
                ////جمعه

                IsInMonth = int.Parse(date.Split('/')[1]) == Month;
                Week = (DayOfWeek)DateShamsi.GetDayOfWeek(date);
                obj.TBODY_Table_Calender += GetTableCalenderDay(currentDate, date, IsInMonth, Week, DayOfWeek.Friday, obj.personIds, personname);
                date = Week == DayOfWeek.Friday ? DateShamsi.AddDaysToShamsiDate(date, 0, 0, 1) : date;

                obj.TBODY_Table_Calender += " </tr> ";

            }
        }

        private string GetTableCalenderDay(string currentDate, string date, bool IsInMonth, DayOfWeek Week, DayOfWeek dayofweek, string personids, string personsName)
        {
            string current_color = "background-color:#e8ffbb";
            string notValid_color = "background-color: #e4e6e0";

            string str = "";
            str += " <th onclick = \"" + ((Week == dayofweek && IsInMonth) ? "ShowListDialog('" + date + "','" + (personids == "" ? "" : (EncryptedQueryString.Encrypt(personids))) + "','" + personsName + "','0'); " : "") + "\" class=\"Farsi_\" style=\"text-align: center; " + ((Week == dayofweek && IsInMonth) ? "cursor:pointer; " : "") + ((Week != dayofweek && IsInMonth) ? notValid_color : ((IsInMonth && currentDate.CompareTo(date) == 0) ? current_color : ((IsInMonth && currentDate.CompareTo(date) <= 0) ? "" : notValid_color))) + " \"> ";
            str += " <div style =\"float: right; padding: 3px; font-size: 22px;\" > ";
            str += (Week == dayofweek && IsInMonth) ? (date.Split('/')[2]) : "";
            str += " </div> ";
            str += "  <div class=\"breakdiv_1\" style=\"height: 3px\"></div> ";
            str += "  <div style = \"width: 100%; text-align: center; padding: 2px\" > ";
            str += (Week == dayofweek && IsInMonth) ? (dc.Nobats.Count(s => s.DateNobat == date && (personids == "" || s.UsersId.ToString() == personids) && s.IsDeleted == false).ToString() + " نوبت") : "         &nbsp; ";
            str += "  </div> ";
            str += "  <div class=\"breakdiv_1\" style=\"height: 5px\"> ";
            str += "  </div> ";
            str += " </th> ";

            return str;
        }
        private CalenderTimeSheetModel Bind_CalenderTimeSheetModel(FormCollection form)
        {
            CalenderTimeSheetModel obj = new CalenderTimeSheetModel(CurrentUser);
            obj.hfServiceTypeContent = form["hfServiceTypeContent"].ToString().Trim();
            obj.cbopersonelSelect = form["cbopersonel"].ToString().Trim();
            return obj;
        }
        private string GetDate(int addmonth)
        {
            string date = EmoNetUtility.GetQueryString("date", (string)RouteData.Values["id"]);
            date = DateShamsi.GetShamsiDateString(date + "/" + "07");
            if (date == null || date.Trim() == "")
                date = DateShamsi.GetCurrentDate();
            List<string> lstDate = date.Split('/').ToList();
            string Date = (lstDate[0] + "/" + lstDate[1]) + "/" + "07";
            Date = DateShamsi.AddDaysToShamsiDate(Date, 0, addmonth, 0);
            lstDate = Date.Split('/').ToList();
            return lstDate[0] + "/" + lstDate[1];
        }
        private void DeleteRow_NobatType(string Id)
        {
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == Id);
            if (obj == null)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("هیچ نوبتی یافت نشد.");
                return;
            }
            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("نوبت با موفقیت حذف گردید");
            if (ischange)
            {
                EventLog.Loging("' نوبت مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName
                                    + "' با تاریخ '" + obj.DateNobat
                                    + "' و ساعت شروع '" + obj.TimeNobat
                                    + " با خدمات '" + (obj.NobatTypes.Any() ? (obj.NobatTypes.Select(s => s.ServiceType.Name).Aggregate((a, b) => a + " , " + b)) : "")
                                    + "' مربوط به پرسنل '" + obj.user.FullName
                                    + "' حذف گردید.", EventTypeIds.DELETE, CurrentUser.Id);
            }
            //کنسل کردن پیامک
        }
        private void AnjamShod(string Id)
        {
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == Id);
            obj.VaziatNobat = VaziatNobatType.DONE_;

            obj.DateAnjamNobat = DateShamsi.GetCurrentDate();
            obj.TimeAnjamNobat = DateShamsi.GetCurrentHour();

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();

            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید.");
            if (ischange)
            {
                EventLog.Loging("' نوبت مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName
                    + "' با تاریخ '" + obj.DateNobat
                    + "' و ساعت شروع '" + obj.TimeNobat
                    + " با خدمات '" + (obj.NobatTypes.Any() ? (obj.NobatTypes.Select(s => s.ServiceType.Name).Aggregate((a, b) => a + " , " + b)) : "")
                    + "' مربوط به پرسنل '" + obj.user.FullName
                    + "' پایان یافت.", EventTypeIds.PayanYaftan, CurrentUser.Id);
            }

            if (obj.Costomer.IsSendSMS)
            {
                string msgbody = (obj.Costomer.IsSexWoman == null ? "خانم/آقای " : (obj.Costomer.IsSexWoman == true ? "خانم " : "آقای ")) + obj.Costomer.FullName
            + " از این که " + PishfarzSpa.Name + " را جهت انجام خدمات خود انتخاب نموده اید کمال تشکر را داریم.  " + Environment.NewLine
             + "مدیریت " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
                SmsUtility.SimpleSendSingleMessage(obj.Costomer.Mobile, msgbody, null, obj.UID, obj.CostomerId);
                EventLog.Loging("پیام کوتاه '" + msgbody + "' توسط سیستم ارسال گردید.", EventTypeIds.ErsalPayamKotahSystemi, CurrentUser.Id);
            }
        }
        [HttpPost]
        public JsonResult GetTimeSheet(string date, string personids, string PageIndex, string personname)
        {



            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
            string pids = EncryptedQueryString.Decrypt(personids);
            var q = (from p in dc.Nobats
                     where
                     p.IsDeleted == false
                     &&
                     p.DateNobat == date
                     &&
                     (
                     pids == ""
                     ||
                     p.UsersId.ToString() == pids
                     )
                     select new
                     {
                         p.UID,
                         p.Costomer.FullName,
                         p.Costomer.Mobile,
                         p.TimeNobat,
                         p.DateSabt,
                         p.TimeNobatEnd,
                         NobatTypes = p.NobatTypes,
                         userfullname = p.user.FullName,
                         isanjamshod = p.VaziatNobat == null ? false : (p.VaziatNobat == VaziatNobatType.DONE_)
                     }).OrderBy(s => s.isanjamshod == true).ThenBy(s => s.TimeNobat).ToList();


            GridPageNumber GridPaging = new Models.Controll.GridPageNumber();
            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("وضعیت");
            GridPaging.lst_headerName.Add("نام و نام خانوادگی");
            GridPaging.lst_headerName.Add("شماره همراه");
            GridPaging.lst_headerName.Add("زمان");
            GridPaging.lst_headerName.Add("خدمات");
            GridPaging.lst_headerName.Add("پرسنل");
            GridPaging.lst_headerName.Add("حذف");

            GridPaging.Columns = 9;
            GridPaging.RowRecord = 7;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.currentPage = GridPaging.SetcountGrid(int.Parse("0" + PageIndex));
            GridPaging.IsShowPageNumbering = GridPaging.CountAllRecord > GridPaging.RowRecord;
            GridPaging.maxPageNumber = GridPaging.CountAllRecord % GridPaging.RowRecord == 0 ? ((GridPaging.CountAllRecord / GridPaging.RowRecord)) : ((GridPaging.CountAllRecord / GridPaging.RowRecord) + 1);
            GridPaging.RowRecord = GridPaging.IsShowPageNumbering ? GridPaging.RowRecord : 0;
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q.ToList();

            string str = GridPaging.GetHtmlHeader() + " <tbody> <tr> <td data-title=\"\" style=\"font-size:20px\"  colspan=\"" + GridPaging.Columns + "\" > هیچ نوبتی یافت نشد. </td>  </tr> </tbody> ";

            if (list.Any())
            {
                str = GridPaging.GetHtmlHeader() + " <tbody> ";
                int linnumbere = GridPaging.StartLineNumber - 1;
                foreach (var p in list)
                {
                    str += " <tr> ";
                    str += " </td> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++linnumbere).ToString() + " </td> ";
                    str += " <td  data-title=\"\" > ";
                    str += "     <div onclick=\"ONCLICKEDIT('" + EncryptedQueryString.Encrypt(p.UID.ToString()) + "','btnEditNobatType');\" class=\"fa fa-edit\" style=\"font-size: 20px; font-weight: bold; color: green; cursor: pointer;\"> ";
                    str += "        <span class=\"Farsi_\" style=\"font-size: 18px; font-weight: bold; color: green; cursor: pointer;\">ویراش</span> ";
                    str += "     </div> ";
                    str += " </td> ";
                    str += " <td data-title=\"\"  > ";
                    str += "     <div " + (p.isanjamshod == true ? "" : (" onclick=\"if(confirm('آیا خدمت مشتری انجام شده است؟'))ClickAnjamShod('" + EncryptedQueryString.Encrypt(p.UID.ToString()) + "','btnAnjamShodNobat'); return false;\""));
                    str += " class=\"fa fa-" + (p.isanjamshod == true ? "check " : "square-o") + "\" style=\"font-size: 20px; font-weight: bold; " + (p.isanjamshod == true ? "color: green; " : "color:red;cursor: pointer;") + "\"> ";
                    str += "         <span class=\"Farsi_\" style=\"font-size: 18px; font-weight: bold; " + (p.isanjamshod == true ? "color: green; " : "color:red;cursor: pointer;") + "\">" + (p.isanjamshod == true ? "انجام شد " : "انجام نشده است") + "</span> ";
                    str += "     </div> ";
                    str += " <td data-title=\"نام و نام خانوادگی\"> " + p.FullName + " </td> ";
                    str += " <td class=\"numeric\" data-title=\"شماره همراه\"> " + "0" + (p.Mobile) + " </td> ";
                    str += " <td data-title=\"زمان\"> " + p.TimeNobat + " الی " + p.TimeNobatEnd + " </td> ";
                    str += " <td data-title=\"خدمات\"> " + (p.NobatTypes.Any() ? p.NobatTypes.Select(s => s.ServiceType.Name).Aggregate((a, b) => a + ", " + b) : "-") + " </td> ";
                    str += " <td data-title=\"پرسنل\"> " + p.userfullname + " </td> ";
                    str += " <td data-title=\"\"  > ";
                    str += "     <div onclick=\"if(confirm('آیا مایل به حذف نوبت انتخاب شده می باشید؟'))ONCLICKREMOVE('" + EncryptedQueryString.Encrypt(p.UID.ToString()) + "','btnRemoveNobatType'); return false;\" class=\"fa fa-remove\" style=\"font-size: 20px; font-weight: bold; color: red; cursor: pointer;\"> ";
                    str += "         <span class=\"Farsi_\" style=\"font-size: 18px; font-weight: bold; color: red; cursor: pointer;\">حذف</span> ";
                    str += "     </div> ";
                    str += " </td>   </tr> ";
                }
                str += " </tbody> ";
                str += GetTableTimeSheetCalenderFooter(GridPaging, date, personids, personname);

            }
            return Json(str);
        }
        private string GetTableTimeSheetCalenderFooter(GridPageNumber GridPaging, string date, string personids, string personname)
        {
            string strhtml = "";
            if (GridPaging.IsShowPageNumbering)
            {
                strhtml += " <tr style=\"background-color: #cbd1c2; border: 1px solid #a9a9a9\"> ";

                strhtml += "  <td style=\"right:0;padding-right:5px;font-size:16px\" colspan=\"" + GridPaging.Columns.ToString() + "\" > ";
                if (GridPaging.currentPage >= GridPaging.PageNumber)
                {

                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
                    strhtml += " name=\"pageIndex\" type=\"submit\"  onclick=\"ShowListDialog('" + date + "','" + personids + "','" + personname + "','" + (GridPaging.StartPageNumber - 1) + "');return false;\" value =\"" + (GridPaging.StartPageNumber - 1) + "\" > ";
                    strhtml += " " + GridPaging.Prview + " ";
                    strhtml += " </button> ";
                }

                for (int i = GridPaging.StartPageNumber; i < (GridPaging.EndPageNumber); i++)
                {
                    if (i == GridPaging.currentPage)
                    {

                        strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += "name= \"pageIndex\"  onclick=\"ShowListDialog('" + date + "','" + personids + "','" + personname + "','" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                    else
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += " name=\"pageIndex\"  onclick=\"ShowListDialog('" + date + "','" + personids + "','" + personname + "','" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                }

                if (((GridPaging.maxPageNumber - 1) / GridPaging.PageNumber) > ((GridPaging.currentPage) / GridPaging.PageNumber))
                {
                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex\" ";
                    strhtml += " type=\"submit\" onclick=\"ShowListDialog('" + date + "','" + personids + "','" + personname + "','" + GridPaging.EndPageNumber + "');return false;\" value=\"" + GridPaging.EndPageNumber + "\" > ";
                    strhtml += " " + GridPaging.Next + " ";
                    strhtml += " </button> ";

                }

                strhtml += "  </td> ";

                strhtml += " </tr> ";

            }

            return strhtml;
        }
        public ActionResult CalenderTimeSheet()
        {

            CalenderTimeSheetModel obj = new CalenderTimeSheetModel(CurrentUser);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.cbopersonelSelect = Utility.EncryptedQueryString.Encrypt(EmoNetUtility.GetQueryString("personids", (string)RouteData.Values["id"]));
            BindPersonelCamboBox(obj);


            Display_Table(obj);
            return View("CalenderTimeSheet", obj);
        }

        private void BindPersonelCamboBox(CalenderTimeSheetModel obj)
        {
            obj.lstpersonel = (from s in dc.users
                               where
                               s.IsDelete == false
                              &&
                              s.UserServices.Any(t => t.IsDeleted == false)
                              &&
                              (
                              CurrentUser.RoleId != RoleIds.PersonelIds
                              ||
                              (CurrentUser.RoleId == RoleIds.PersonelIds && CurrentUser.Id == s.Id)
                              )
                               select s).OrderBy(s => s.FullName).ToList();


            if (obj.lstpersonel.Any(s => s.Id.ToString() == obj.personIds) == false)
                obj.cbopersonelSelect = "";

            if (CurrentUser.RoleId == RoleIds.PersonelIds)
                obj.cbopersonelSelect = Utility.EncryptedQueryString.Encrypt(CurrentUser.Id.ToString());
        }

        [HttpPost]
        public ActionResult CalenderTimeSheet(string btn, FormCollection form)
        {

            CalenderTimeSheetModel obj = Bind_CalenderTimeSheetModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            BindPersonelCamboBox(obj);

            if (btn == "REMOVE")
            {
                if (!obj.security.IsDelete)
                {
                    ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه حذف اطلاعات را ندارید.");

                }
                else
                    DeleteRow_NobatType(EncryptedQueryString.Decrypt(form["hfDeleteId"].ToString().Trim()));
            }
            else if (btn == "NEW")
            {
                return GoToPage("TimeSheetSpec", "Application", "date=" + form["hfdate"].ToString().Trim() + "&personids=" + obj.personIds);
            }
            else if (btn == "EDIT")
            {
                string uid = EncryptedQueryString.Decrypt(form["hfEditId"].ToString().Trim());
                var temp = dc.Nobats.FirstOrDefault(s => s.UID.ToString() == uid);
                if (temp != null)
                    return GoToPage("TimeSheetSpec", "Application", "ID=" + uid + "&date=" + form["hfdate"].ToString().Trim() + "&personids=" + temp.UsersId.ToString());
            }
            else if (btn == "ANJAMSHOD")
            {
                if (!obj.security.IsEdit)
                {
                    ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه ثبت اطلاعات را ندارید.");

                }
                else
                    AnjamShod(EncryptedQueryString.Decrypt(form["hfEditId"].ToString().Trim()));
            }
            else if (btn == "PRE")
            {
                return GoToPage("CalenderTimeSheet", "Application", "date=" + GetDate(-1) + "&personids=" + obj.personIds);
            }
            else if (btn == "NEXT")
            {
                return GoToPage("CalenderTimeSheet", "Application", "date=" + GetDate(1) + "&personids=" + obj.personIds);
            }
            else if (btn == "TODAY")
            {

                return GoToPage("CalenderTimeSheet", "Application", "date=" + DateShamsi.GetCurrentDate().Split('/')[0] + "/" + DateShamsi.GetCurrentDate().Split('/')[1] + "&personids=" + obj.personIds);
            }

            Display_Table(obj);
            return View("CalenderTimeSheet", obj);
        }


        #endregion

        #region TimeSheet


        [HttpPost]
        public JsonResult SaveCustomers(string name, string family, string sexIndex, string telcode, string tel, string mobile, string allowtekrari, string smsindex, string dsc)
        {
            string RESULT = CheckValidateCustomer(name, family, sexIndex, telcode, tel, mobile, allowtekrari, smsindex, dsc);
            if (RESULT.StartsWith("SUCCESS"))
            {
                RESULT += SaveNewCustomer(name, family, sexIndex, telcode, tel, mobile, allowtekrari, smsindex, dsc);
            }

            return Json(RESULT);
        }

        private string CheckValidateCustomer(string name, string family, string sexIndex, string telcode, string tel, string mobile, string allowtekrari, string smsindex, string dsc)
        {
            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
            bool result = true;
            string Msg = "";
            int i = 1;

            Models.Security sec = new Models.Security(CurrentUser, "customers");
            if (!sec.IsSave)
            {
                Msg = "ERROR;" + "شما اجازه ثبت مشتری جدید را ندارید ";
            }
            if (name.Trim() == "")
            {
                Msg += (i++) + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (family.Trim() == "")
            {
                Msg += (i++) + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }

            if (mobile.Trim() == "" || mobile.Trim().Length != 10)
            {
                Msg += (i++) + " - " + "شماره همراه را صحیح وارد نمایید." + "</br>";
                result = false;

            }
            else
            {


                if (dc.Costomers.Any(s => s.Mobile == mobile.Trim() && s.IsDelete == false))
                {
                    if (allowtekrari.ToLower() == "false")
                    {


                        Msg += (i++) + " - " + "شماره موبایل وارد شده با مشتری دیگری یکسان می باشد. در صورت تمایل به ثبت مشتری با همین شماره تیک مربوطه را کلیک نمایید." + "</br>";
                        result = false;



                    }
                    Msg = "ALLOW;" + Msg;
                }
                else
                {

                }
            }





            if (!result)
            {
                Msg = "ERROR;" + Msg;
            }
            else
                Msg = "SUCCESS;";


            return Msg;
        }

        private string SaveNewCustomer(string name, string family, string sexIndex, string telcode, string tel, string mobile, string allowtekrari, string smsindex, string dsc)
        {
            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
            Costomer obj = new Costomer();
            obj.Id = dc.Costomers.Any() == false ? 1 : (dc.Costomers.Max(s => s.Id) + 1);
            dc.Costomers.InsertOnSubmit(obj);
            obj.IsDelete = false;



            obj.Name = name.Trim();
            obj.Family = family.Trim();
            obj.Mobile = mobile.Trim();
            obj.Tel = tel.Trim();
            obj.TelCode = telcode.Trim();
            obj.Dsc = dsc;
            if (sexIndex.ToString() == "0")
            {
                obj.IsSexWoman = true;
            }
            else
            {
                obj.IsSexWoman = false;
            }

            obj.IsSendSMS = smsindex == "0";
            obj.IsAddCoustomerWithUnUniqeMobileNumber = dc.Costomers.Any(s => s.Mobile == obj.Mobile && s.Id != obj.Id && s.IsDelete == false);

            dc.SubmitChanges();
            EventLog.Loging(" مشتری با نام و  نام خانوادگی '" + obj.FullName + "' با شماره همراه '" + obj.Mobile + "' درج گردید.(از صفحه نوبت دهی)", EventTypeIds.SAVE, CurrentUser.Id);
            return EncryptedQueryString.Encrypt(obj.Id.ToString()) + ";" + obj.FullName;
        }
        private TimeSheetSpecModel Display_TimeSheet()
        {
            dc = new dbAvaSpaDataContext();
            string date = EmoNetUtility.GetQueryString("date", (string)RouteData.Values["id"]);
            string ID = EmoNetUtility.GetQueryString("ID", (string)RouteData.Values["id"]);
            ID = ID == null ? "" : ID.Trim();
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);

            string personids = EmoNetUtility.GetQueryString("personids", (string)RouteData.Values["id"]);
            TimeSheetSpecModel timesheet = new TimeSheetSpecModel(CurrentUser, ID, personids);


            if (obj == null)
            {
                timesheet.txtDate = date;
                timesheet.txtTimeAz = dc.Nobats.Any(s => s.DateNobat == date && s.UsersId.ToString() == personids && s.IsDeleted == false) ? dc.Nobats.Where(s => s.DateNobat == date && s.UsersId.ToString() == personids && s.IsDeleted == false).Select(s => s.TimeNobatEnd).Max(s => s) : "";
                return timesheet;
            }

            timesheet.ISEDITMode = (obj.VaziatNobat == VaziatNobatType.DONE_) ? "true" : "false";
            timesheet.btnShowSave = (obj.VaziatNobat == VaziatNobatType.DONE_) ? "false" : "true";
            timesheet.btnShowAnjamShod = (obj.VaziatNobat != VaziatNobatType.DONE_).ToString().ToLower();


            timesheet.txtDate = obj.DateNobat;
            timesheet.txtTimeAz = obj.TimeNobat;
            timesheet.txtTimeTa = obj.TimeNobatEnd;
            timesheet.hfIdOfCustomer = EncryptedQueryString.Encrypt(obj.CostomerId.ToString());
            timesheet.hfNameOfCustomer = obj.Costomer.FullName;
            timesheet.txtDsc = obj.Dsc;
            List<int> lstcheck = obj.NobatTypes.Where(s => s.IsDeleted == false).Select(s => s.ServiceTypeId).ToList();

            foreach (int item in lstcheck)
            {
                string IDItem = EncryptedQueryString.Encrypt(item.ToString());
                if (timesheet.ListcheckBox.FirstOrDefault(s => s.Id == IDItem) != null)
                    timesheet.ListcheckBox.FirstOrDefault(s => s.Id == IDItem).Value = "true";

            }

            return timesheet;
        }
        private ActionResult ReturnToCalanderTimeSheet()
        {
            string personids = EmoNetUtility.GetQueryString("personids", (string)RouteData.Values["id"]);
            string date = EmoNetUtility.GetQueryString("date", (string)RouteData.Values["id"]);
            date = DateShamsi.GetShamsiDateString(date);
            if (date == "")
                date = DateShamsi.GetCurrentDate();
            date = date.Split('/')[0] + "/" + date.Split('/')[1];
            return GoToPage("CalenderTimeSheet", "Application", "date=" + date + "&personids=" + personids);
        }
        private TimeSheetSpecModel Bind_TimeSheetSpecModel(FormCollection form)
        {
            string ID = EmoNetUtility.GetQueryString("ID", (string)RouteData.Values["id"]);
            ID = ID == null ? "" : ID.Trim();
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);

            string personids = EmoNetUtility.GetQueryString("personids", (string)RouteData.Values["id"]);
            TimeSheetSpecModel timesheet = new TimeSheetSpecModel(CurrentUser, ID, personids);

            if (obj != null)       ///در حال حاضر امکان ویرایش وجود ندارد پس همه ایتمها غیر فعال شود
            {
                timesheet.ISEDITMode = (obj.VaziatNobat == VaziatNobatType.DONE_) ? "true" : "false";
                timesheet.btnShowSave = (obj.VaziatNobat == VaziatNobatType.DONE_) ? "false" : "true";
                timesheet.btnShowAnjamShod = (obj.VaziatNobat != VaziatNobatType.DONE_).ToString().ToLower();
            }

            timesheet.txtSearch = form["txtSearch"].ToString().Trim();
            timesheet.txtDate = form["txtDate"] == null ? (obj != null ? obj.DateNobat : "") : form["txtDate"].ToString().Trim();

            timesheet.txtDsc = form["txtDsc"] == null ? (obj != null ? obj.Dsc : "") : form["txtDsc"].ToString().Trim();
            timesheet.txtTimeAz = form["txtTimeAz"] == null ? (obj != null ? obj.TimeNobat : "") : form["txtTimeAz"].ToString().Trim();
            timesheet.txtTimeTa = form["txtTimeTa"] == null ? (obj != null ? obj.TimeNobatEnd : "") : form["txtTimeTa"].ToString().Trim();
            timesheet.hfIdOfCustomer = form["hfIdOfCustomer"].ToString();
            timesheet.hfNameOfCustomer = form["hfNameOfCustomer"].ToString();

            List<string> lstcheck = form.AllKeys.Where(s => s.StartsWith("ListcheckBox")).ToList();

            foreach (string item in lstcheck)
            {
                string IDItem = item.Substring("ListcheckBox".Length).ToString();
                if (timesheet.ListcheckBox.FirstOrDefault(s => s.Id == IDItem) != null)
                    timesheet.ListcheckBox.FirstOrDefault(s => s.Id == IDItem).Value = "true";
                else
                {
                    string IDVAlue = EncryptedQueryString.Decrypt(IDItem);
                    var it = dc.ServiceTypes.FirstOrDefault(s => s.Id.ToString() == IDVAlue);
                    if (it != null)
                    {
                        timesheet.ListcheckBox.Add(new CCheckbox { Id = IDItem, Name = it.Name, Value = "true" });
                    }
                }

            }

            return timesheet;
        }
        public ActionResult TimeSheetSpec()
        {
            TimeSheetSpecModel obj = Display_TimeSheet();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (obj.personids == null)
                return ReturnToCalanderTimeSheet();
            return View("TimeSheetSpec", obj);
        }
        [HttpPost]
        public ActionResult TimeSheetSpec(string btn, FormCollection form)
        {
            TimeSheetSpecModel obj = Bind_TimeSheetSpecModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (obj.personids == null)
                return ReturnToCalanderTimeSheet();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(CurrentUser.Id, false);
                    ViewBag.MessageDialogInfo = obj.Message;
                    return ReturnToCalanderTimeSheet();
                }
                else
                    ViewBag.MessageDialogInfo = obj.Message;

            }
            if (btn == "SAVE_SEND_MESSAGE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(CurrentUser.Id, true);
                    ViewBag.MessageDialogInfo = obj.Message;
                    return ReturnToCalanderTimeSheet();
                }
                else
                    ViewBag.MessageDialogInfo = obj.Message;

            }
            else if (btn == "ANJAMSHOD")
            {
                obj.SendSmsPayamTashakor(CurrentUser.Id);
                ViewBag.MessageDialogInfo = obj.Message;
                obj = Display_TimeSheet();
            }
            else if (btn == "CANCEL")
            {
                return ReturnToCalanderTimeSheet();
            }

            return View("TimeSheetSpec", obj);
        }

        #endregion



        #endregion

        #region SMS Package
        #region sms

        private void RemoveSms(string Id)
        {
            var obj = dc.MessageSms.SingleOrDefault(s => s.UID.ToString() == Id);
            if (obj == null || obj.IsDeleted == true)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }

            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" پیام کوتاه با پیام '" + obj.Message + "' مربوط به مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName + "' که در تاریخ '" + obj.DateErsal + "' و زمان '" + obj.TimeErsal + "' ارسال شده است حذف گردید.", EventTypeIds.DELETE, CurrentUser.Id);

        }
        private void Search_SMS(SMSModel obj)
        {
            FieldFullName = obj.txtFullName.Trim();
            FieldMobileNumber = obj.txtMobile.Trim();
            Fieldhfvalue = obj.hfContent;
            string dateaz = DateShamsi.GetShamsiDateString(obj.txtDateAz.Trim());
            string dateta = DateShamsi.GetShamsiDateString(obj.txtDateTa.Trim());
            FieldDATEAZ = dateaz;
            FieldDATETA = dateta;
            OldPageIndex = obj.pageIndex;

            int count_grid = int.TryParse("0" + obj.pageIndex, out count_grid) ? count_grid : 0;
            var q1 = (from p in dc.MessageSms
                      where
                      p.IsDeleted == false
                      &&
                      (
                            (obj.txtFullName.Trim() == ""
                            ||
                            p.Costomer.FullName.Contains(obj.txtFullName.Trim()))
                            &&
                            (obj.txtMobile.Trim() == ""
                            ||
                            ("0" + p.Costomer.Mobile).Contains(obj.txtMobile.Trim()))
                            &&
                           (
                            (dateaz == "" && dateta == "")
                            ||
                            (dateaz != "" && (p.DateErsal).CompareTo(dateaz) >= 0)
                            ||
                            (dateta != "" && (p.DateErsal).CompareTo(dateta) <= 0)

                            )
                      )
                      select p).OrderByDescending(s => s.DateErsal).ThenByDescending(s => s.TimeErsal).ThenByDescending(s => s.DateTimeSabt).ToList();


            obj.lblcountSMS = 0;

            if (q1.Any())
            {
                obj.lblcountSMS = q1.Count();

            }

            obj.GridPaging.Columns = 7;
            obj.GridPaging.CountAllRecord = q1.Count();
            obj.GridPaging.currentPage = obj.GridPaging.SetcountGrid(count_grid);
            obj.GridPaging.IsShowPageNumbering = obj.GridPaging.CountAllRecord > obj.GridPaging.RowRecord;
            obj.GridPaging.maxPageNumber = obj.GridPaging.CountAllRecord % obj.GridPaging.RowRecord == 0 ? ((obj.GridPaging.CountAllRecord / obj.GridPaging.RowRecord)) : ((obj.GridPaging.CountAllRecord / obj.GridPaging.RowRecord) + 1);
            obj.GridPaging.RowRecord = obj.GridPaging.IsShowPageNumbering ? obj.GridPaging.RowRecord : 0;
            obj.lstsms = obj.GridPaging.IsShowPageNumbering ? q1.Skip(obj.GridPaging.currentPage * obj.GridPaging.RowRecord).Take(obj.GridPaging.RowRecord).ToList() : q1.ToList();



        }
        private SMSModel Bind_SMSModel(FormCollection form)
        {
            SMSModel sms = new SMSModel(CurrentUser);
            sms.txtDateTa = form["txtDateTa"].ToString().Trim();
            sms.hfContent = form["hfContent"].ToString().Trim();
            sms.txtMobile = form["txtMobile"].ToString().Trim();
            sms.txtDateAz = form["txtDateAz"].ToString().Trim();
            sms.txtFullName = form["txtFullName"].ToString().Trim();
            sms.pageIndex = form["pageIndex"] == null ? form["hfCurrentPageIndex"].ToString().Trim() : (form["pageIndex"].ToString().Trim());
            return sms;
        }
        private SMSModel SetOldParametr_SMS()
        {
            SMSModel obj = new SMSModel(CurrentUser);
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {

                    obj.txtMobile = FieldMobileNumber;
                    obj.txtDateAz = FieldDATETA;
                    obj.txtDateTa = FieldDATEAZ;
                    obj.hfContent = Fieldhfvalue;
                    obj.txtFullName = FieldFullName;
                    obj.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        public ActionResult sms()
        {


            SMSModel sms = SetOldParametr_SMS();
            Search_SMS(sms);
            if (!sms.security.IsDisplay)
                return GOLOGIN();
            return View("SMS", sms);


        }
        [HttpPost]
        public ActionResult sms(string btn, FormCollection form)
        {

            SMSModel obj = Bind_SMSModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                if (obj.security.IsDelete)
                {
                    ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("اجازه حذف اطلاعات وجود ندارد");

                }
                else
                    RemoveSms(EncryptedQueryString.Decrypt(form["hfDeleteId"].ToString().Trim()));
            }
            else if (btn == "NEW")
            {
                return GoToPage("SMSSpec", "APPLICATION");
            }
            if (btn == "EDIT")
            {
                return GoToPage("SMSSpec", "APPLICATION", "ID=" + EncryptedQueryString.Decrypt(form["hfEditId"].ToString().Trim()));
            }
            Search_SMS(obj);
            return View("SMS", obj);

        }

        #endregion

        #region smsSpec



        public ActionResult SMSSpec()
        {


            return View("SMSSpec", new SMSSPECModel(EmoNetUtility.GetQueryString("ID", (string)RouteData.Values["id"]), CurrentUser));


        }
        [HttpPost]
        public ActionResult SMSSpec(string btn, FormCollection form)
        {

            SMSSPECModel sms = new SMSSPECModel(form, EmoNetUtility.GetQueryString("ID", (string)RouteData.Values["id"]), CurrentUser);
            if (!sms.security.IsDisplay)
                return GOLOGIN();
            if (btn == "CANCEL")
            {
                return GoToPage("SMS", "Application", "index=old");
            }
            else if (btn == "SEND")
            {
                if (sms.CheckValidate())
                {
                    sms.Send();
                    EventLog.Loging(" پیامک برای مشتری ها با نام و نام خانوادگی '" + sms.hfNameOfReciver + "' با متن پیام '" + sms.txtMsg.Trim() + "' درج گردید.", EventTypeIds.ErsalPayamKotahDasti, CurrentUser.Id);

                    ViewBag.MessageDialogInfo = sms.Message;
                    return GoToPage("SMS", "Application", "index=old");
                }
                else
                {
                    ViewBag.MessageDialogInfo = sms.Message;
                }
            }
            return View("SMSSpec", sms);

        }
        #endregion
        #endregion

        #region Customers Package

        #region Customers
        private CustomersModel SetOldParametr_Customers()
        {
            CustomersModel obj = new CustomersModel(CurrentUser);
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtFullName = FieldFullName;
                    obj.txtMobile = FieldMobileNumber;
                    obj.hfContent = Fieldhfvalue;
                    obj.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private CustomersModel Bind_CustomersModel(FormCollection form)
        {
            CustomersModel obj = new CustomersModel(CurrentUser);
            obj.hfContent = form["hfContent"].ToString().Trim();
            obj.txtFullName = form["txtFullName"].ToString().Trim();
            obj.txtMobile = form["txtMobile"].ToString().Trim();
            obj.pageIndex = form["pageIndex"] == null ? form["hfCurrentPageIndex"].ToString().Trim() : (form["pageIndex"].ToString().Trim());
            return obj;
        }
        private void Remove_Customers(string Id)
        {
            var obj = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == Id);

            if (obj == null || obj.IsDelete == true)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }

            obj.IsDelete = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" مشتری با نام و نام خانوادگی '" + obj.FullName + "' حذف گردید.", EventTypeIds.DELETE, CurrentUser.Id);

        }
        private void Search_Customers(CustomersModel obj)
        {
            FieldFullName = obj.txtFullName.Trim();
            FieldMobileNumber = obj.txtMobile.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.pageIndex;

            int count_grid = int.TryParse("0" + obj.pageIndex, out count_grid) ? count_grid : 0;
            var q1 = (from p in dc.Costomers
                      where
                      p.IsDelete == false
                      &&
                      (
                            (obj.txtFullName.Trim() == ""
                            ||
                            p.FullName.Contains(obj.txtFullName.Trim()))
                            &&
                            (obj.txtMobile.Trim() == ""
                            ||
                            ("0" + p.Mobile).Contains(obj.txtMobile.Trim()))
                      )
                      select p).OrderBy(s => s.Family).ThenBy(s => s.Name).ToList();


            obj.CountSearchRow = "0";


            if (q1.Any())
            {
                obj.CountSearchRow = q1.Count().ToString();

            }
            obj.GridPaging.Columns = 7;
            obj.GridPaging.CountAllRecord = q1.Count();
            obj.GridPaging.currentPage = obj.GridPaging.SetcountGrid(count_grid);
            obj.GridPaging.IsShowPageNumbering = obj.GridPaging.CountAllRecord > obj.GridPaging.RowRecord;
            obj.GridPaging.maxPageNumber = obj.GridPaging.CountAllRecord % obj.GridPaging.RowRecord == 0 ? ((obj.GridPaging.CountAllRecord / obj.GridPaging.RowRecord)) : ((obj.GridPaging.CountAllRecord / obj.GridPaging.RowRecord) + 1);
            obj.GridPaging.RowRecord = obj.GridPaging.IsShowPageNumbering ? obj.GridPaging.RowRecord : 0;
            obj.ListGried = obj.GridPaging.IsShowPageNumbering ? q1.Skip(obj.GridPaging.currentPage * obj.GridPaging.RowRecord).Take(obj.GridPaging.RowRecord).ToList() : q1.ToList();



        }
        public ActionResult Customers()
        {

            CustomersModel obj = SetOldParametr_Customers();
            Search_Customers(obj);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("Customers", obj);
        }
        [HttpPost]
        public ActionResult Customers(string btn, FormCollection form)
        {


            CustomersModel obj = Bind_CustomersModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                if (!obj.security.IsDelete)
                {
                    ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه حذف اطلاعات را ندارید");

                }
                else
                    Remove_Customers(EncryptedQueryString.Decrypt(form["hfDeleteId"].ToString().Trim()));
            }
            else if (btn == "NEW")
            {

                return GoToPage("CustomerSpec", "Application");


            }
            else if (btn == "EDIT")
            {


                return GoToPage("CustomerSpec", "Application", "id=" + EncryptedQueryString.Decrypt(form["hfEditId"].ToString().Trim()));
            }

            Search_Customers(obj);
            return View("Customers", obj);
        }





        #endregion

        #region CustomerSpec
        private CustomerSpecModel Display_CustomerSpec()
        {
            string Id = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            CustomerSpecModel cus = new CustomerSpecModel(CurrentUser);
            var obj = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
                return cus;
            cus.Id = EncryptedQueryString.Encrypt(obj.Id.ToString());
            cus.Dsc = obj.Dsc;
            cus.Family = obj.Family;
            cus.IsAddCoustomerWithUnUniqeMobileNumber = obj.IsAddCoustomerWithUnUniqeMobileNumber.ToString().ToLower();
            cus.IsSendSMS = obj.IsSendSMS.ToString().ToLower();
            cus.IsSexWoman = obj.IsSexWoman == null ? "" : obj.IsSexWoman.ToString().ToLower();
            cus.Mobile = obj.Mobile;
            cus.Name = obj.Name;
            cus.Tel = obj.Tel;
            cus.ShowParvandeBimar = "true";
            cus.TelCode = obj.TelCode;
            if (obj.IsAddCoustomerWithUnUniqeMobileNumber)
                cus.ShowAddCoustomerAllowMobileNumber = "";
            return cus;
        }
        private bool CheckValidate_CustomerSpec(CustomerSpecModel obj)
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            if (!obj.security.IsSave)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            if (obj.Name.Trim() == "")
            {
                Msg += (i++) + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (obj.Family.Trim() == "")
            {
                Msg += (i++) + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }

            if (obj.Mobile.Trim() == "" || obj.Mobile.Trim().Length != 10)
            {
                Msg += (i++) + " - " + "شماره همراه را صحیح وارد نمایید." + "</br>";
                result = false;
                obj.ShowAddCoustomerAllowMobileNumber = "none";
            }
            else
            {
                string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
                ID = ID == null ? "" : ID.Trim();
                if (dc.Costomers.Any(s => s.Mobile == obj.Mobile.Trim() && s.Id.ToString() != ID && s.IsDelete == false))
                {
                    if (obj.IsAddCoustomerWithUnUniqeMobileNumber == "false")
                    {


                        Msg += (i++) + " - " + "شماره موبایل وارد شده با مشتری دیگری یکسان می باشد. در صورت تمایل به ثبت مشتری با همین شماره تیک مربوطه را کلیک نمایید." + "</br>";
                        result = false;
                        obj.ShowAddCoustomerAllowMobileNumber = "";


                    }
                }
                else
                {
                    obj.ShowAddCoustomerAllowMobileNumber = "none";
                }
            }





            if (!result)
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage(Msg);
            return result;
        }

        private void Save_CustomerSpec(CustomerSpecModel cus)
        {
            bool IsEdit = true;
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            var obj = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == ID);

            if (obj == null)
            {
                obj = new Costomer();
                obj.Id = dc.Costomers.Any() == false ? 1 : (dc.Costomers.Max(s => s.Id) + 1);
                dc.Costomers.InsertOnSubmit(obj);
                obj.IsDelete = false;
                IsEdit = false;
            }

            obj.Name = cus.Name.Trim();
            obj.Family = cus.Family.Trim();
            obj.Mobile = cus.Mobile.Trim();
            obj.Tel = cus.Tel.Trim();
            obj.TelCode = cus.TelCode.Trim();
            obj.Dsc = cus.Dsc.Trim();
            if (cus.IsSexWoman == "true")
            {

                obj.IsSexWoman = true;
            }
            else
            {
                obj.IsSexWoman = false;
            }

            obj.IsSendSMS = cus.IsSendSMS == "true";
            obj.IsAddCoustomerWithUnUniqeMobileNumber = dc.Costomers.Any(s => s.Mobile == obj.Mobile && s.Id != obj.Id && s.IsDelete == false);

            bool Ischange = dc.GetChangeSet().Updates.Any();

            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("اطلاعات وارد شده با موفقیت ذخیره شد.");
            if (IsEdit == false)
                EventLog.Loging(" مشتری با نام و  نام خانوادگی '" + obj.FullName + "' با شماره همراه '" + obj.Mobile + "' درج گردید.", EventTypeIds.SAVE, CurrentUser.Id);
            else if (IsEdit == true && Ischange)
                EventLog.Loging(" مشتری با نام و  نام خانوادگی '" + obj.FullName + "' با شماره همراه '" + obj.Mobile + "' درج گردید.", EventTypeIds.EDIT, CurrentUser.Id);
        }

        private CustomerSpecModel Bind_CustomerSpecModel(FormCollection form)
        {
            CustomerSpecModel cus = new CustomerSpecModel(CurrentUser);
            cus.Id = EncryptedQueryString.Encrypt(EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]));
            cus.Dsc = form["TxtDsc"].ToString().Trim();
            cus.Family = form["txtFamily"].ToString().Trim();
            cus.IsSendSMS = form["CboSms"].ToString().Trim();
            cus.IsSexWoman = form["CboSex"].ToString().Trim();
            cus.Mobile = form["txtMobile"].ToString().Trim();
            cus.Name = form["txtName"].ToString().Trim();
            cus.Tel = form["txtTel"].ToString().Trim();
            cus.IsAddCoustomerWithUnUniqeMobileNumber = form["chkEjazeEzafKardanMoshtariBaTelTekrari"].ToString().Trim();
            cus.TelCode = form["txtTelCode"].ToString().Trim();
            cus.ShowParvandeBimar = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]) == "" ? "false" : "true";
            return cus;
        }
        public ActionResult CustomerSpec()
        {
            return View("CustomerSpec", Display_CustomerSpec());
        }
        [HttpPost]
        public ActionResult CustomerSpec(string btn, FormCollection form)
        {
            CustomerSpecModel obj = Bind_CustomerSpecModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "CANCEL")
            {
                return GoToPage("Customers", "Application", "index=old");
            }
            else if (btn == "SAVE")
            {
                if (CheckValidate_CustomerSpec(obj))
                {
                    Save_CustomerSpec(obj);
                    return GoToPage("Customers", "Application", "index=old");
                }
            }
            return View("CustomerSpec", obj);
        }




        #endregion

        #endregion

        #region Profile
        private void Save_Profile(ProfileModel profile)
        {
            var obj = dc.users.Single(s => s.Id == CurrentUser.Id);

            obj.Name = profile.txtName.Trim();
            obj.Family = profile.txtFamily.Trim();
            obj.Mobile = profile.txtMobile.Trim();
            obj.Tel = profile.txtTel.Trim();
            obj.TelCode = profile.txtTelCode.Trim();
            obj.Address = profile.txtAddress.Trim();
            obj.Email = profile.txtEmail.Trim();
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("اطلاعات وارد شده با موفقیت ذخیره شد.");
            ViewBag.FullName_User = obj.Name + " " + obj.Family;

            if (Ischange)
                EventLog.Loging(" پروفایل کاربری با نام کاربری '" + obj.UserName + "' ویرایش گردید.", EventTypeIds.EDIT, CurrentUser.Id);
        }
        private bool CheckValidate_Profile(ProfileModel obj)
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!obj.security.IsSave)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (obj.txtName.Trim() == "")
            {
                Msg += (i++) + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (obj.txtFamily.Trim() == "")
            {
                Msg += (i++) + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (obj.txtMobile.Trim() == "" || obj.txtMobile.Trim().Count() != 10)
            {
                Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                result = false;

            }
            if (obj.txtEmail.Trim() == "")
            {
                Msg += (i++) + " - " + "ایمیل را وارد نمایید." + "</br>";
                result = false;
            }

            else if (!Validation.IsEmail(obj.txtEmail.Trim()))
            {
                Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (dc.users.Any(S => S.Id != CurrentUser.Id && S.IsDelete == false && S.Email == obj.txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }




            if (!result)
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage(Msg);
            return result;
        }
        private ProfileModel DisplayInfo_Profile()
        {
            ProfileModel obj = new ProfileModel(CurrentUser);

            obj.TxtUserName = CurrentUser.UserName;
            obj.txtName = CurrentUser.Name;
            obj.txtFamily = CurrentUser.Family;
            obj.txtMobile = CurrentUser.Mobile;
            obj.txtTel = CurrentUser.Tel;
            obj.txtTelCode = CurrentUser.TelCode;
            obj.txtAddress = CurrentUser.Address;
            obj.txtEmail = CurrentUser.Email;

            return obj;
        }
        private ProfileModel Bind_ProfileModel(FormCollection form)
        {
            ProfileModel obj = new ProfileModel(CurrentUser);
            obj.TxtUserName = CurrentUser.UserName;
            obj.txtName = form["txtName"].ToString().Trim();
            obj.txtFamily = form["txtFamily"].ToString().Trim();
            obj.txtMobile = form["txtMobile"].ToString().Trim();
            obj.txtTel = form["txtTel"].ToString().Trim();
            obj.txtTelCode = form["txtTelCode"].ToString().Trim();
            obj.txtAddress = form["txtAddress"].ToString().Trim();
            obj.txtEmail = form["txtEmail"].ToString().Trim();

            return obj;
        }

        public ActionResult Profiles()
        {


            return View("Profiles", DisplayInfo_Profile());

        }
        [HttpPost]
        public ActionResult Profiles(string btn, FormCollection form)
        {

            ProfileModel obj = Bind_ProfileModel(form);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (CheckValidate_Profile(obj))
                {
                    Save_Profile(obj);
                }
            }
            return View("Profiles", obj);

        }


        #endregion

        #region Change Password


        private bool CheckValidate_changePassword(string txtoldpass, string txtPass, string txtrepass)
        {
            bool result = true;
            string msg = "لطفا به نکات زیر توجه فرمایید" + "</br>";
            int i = 0;


            if (CurrentUser.Password != Utility.EncryptedQueryString.GetMD5Hash(txtoldpass))
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور قبلی وارد شده، نادرست می باشد." + "</br>";
            }

            if (txtPass == "")
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور جدید را وارد نمایید." + "</br>";
            }

            else if (txtPass != txtrepass)
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور جدید با تکرار آن یکسان نمی باشد." + "</br>";
            }

            if (!result)
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage(msg);
            return result;
        }
        private void Save_changePassword(string newpass)
        {
            var obj = dc.users.Single(s => s.Id == CurrentUser.Id);
            obj.Password = Utility.EncryptedQueryString.GetMD5Hash(newpass);
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("رمز عبور با موفقیت تغییر یافت");

            if (Ischange)
                EventLog.Loging(" رمز عبور کاربری با نام کاربری '" + obj.UserName + "' ویرایش گردید.", EventTypeIds.EDIT, CurrentUser.Id);
        }
        public ActionResult changePassword()
        {
            PasswordModal obj = new PasswordModal(CurrentUser);

            return View("changePassword", obj);
        }
        [HttpPost]
        public ActionResult changePassword(string btnvalue, string txtoldpass, string txtPass, string txtrepass)
        {
            PasswordModal obj = new PasswordModal(CurrentUser);
            if (btnvalue == "SAVE")
            {
                if (CheckValidate_changePassword(txtoldpass, txtPass, txtrepass))
                {
                    Save_changePassword(txtPass);
                }
            }
            return View("changePassword", obj);
        }
        #endregion

        #region DefaultSetting


        public ActionResult DefaultSetting()
        {

            var obj = new DefaultSettingModel(CurrentUser);
            obj.BindServiceType();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("DefaultSetting", obj);
        }
        [HttpPost]
        public ActionResult DefaultSetting(string btn, FormCollection frm)
        {
            var obj = new DefaultSettingModel(frm, CurrentUser);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVESERVICE")
            {
                obj.DeleteRowsServiceType();
                ViewBag.MessageDialogInfo = obj.Message;
            }
            if (btn == "EDITORADDSERVICE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                }
                ViewBag.MessageDialogInfo = obj.Message;
            }

            obj.BindServiceType();
            return View("DefaultSetting", obj);
        }

        #endregion
        public ActionResult EXIT()
        {
            EventLog.Loging(" خروج کاربر از سامانه", EventTypeIds.khorojAzSystem, CurrentUser.Id);
            Session.Remove("USERID");
            return RedirectToAction("Login", "Login");
        }
    }
}