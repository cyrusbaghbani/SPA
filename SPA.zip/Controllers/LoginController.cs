﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_AVASPA.Models;
using Utility;
using MVC_AVASPA.App_Start.Utility;

namespace MVC_AVASPA.Controllers
{


    public class LoginController : Controller
    {
        private dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
        // GET: Login
        public ActionResult Login()
        {
            Session.Remove("USERID");
            return View("Login");
        }
        [HttpPost]
        public ActionResult Login(string txtUserName, string txtPassword, string btnVorodBSystem, string btnSendMAIL_DIALOG_INFO, string txtbox_EMAIL_DIALOG)
        {
            ActionResult result_action = Login();
            ViewBag.usernametxt = txtUserName;
            if (btnVorodBSystem == "LOGIN")
            {
                if (CheckValidate(txtUserName, txtPassword))
                {
                    login_(txtUserName, txtPassword);
                    result_action = RedirectToAction("CalenderTimeSheet", "Application");

                }
            }
            else if (btnSendMAIL_DIALOG_INFO == "FORGOTPASSWORD")
            {
                if (CheckValidateEmail(txtbox_EMAIL_DIALOG))
                {
                    SendNewPass(txtbox_EMAIL_DIALOG);
                }

            }

            return result_action;
        }

        private void SendNewPass(string txtbox_EMAIL_DIALOG)
        {
            string email = txtbox_EMAIL_DIALOG.Trim();
            string NewPass = (new Random()).Next(1000000, 9999999).ToString();
            user obj = dc.users.FirstOrDefault(s => s.Email == txtbox_EMAIL_DIALOG.Trim());
            obj.Password = EncryptedQueryString.GetMD5Hash(NewPass);
            dc.SubmitChanges();

            string body = "با سلام" + Environment.NewLine + "رمز عبور جدید برای وارد شدن به سایت آوا اسپا عبارت است از : " + NewPass;
            Mailer.SendMail(body, "آوا اسپا", email, false, "رمز عبور جدید");
            ViewBag.MessageDialogInfo = MODELDIALOGController.ShowSeccessMessage("رمز عبور جدید ارسال گردید");
            EventLog.Loging(" رمز عبور به ایمیل ارسال گردید.", EventTypeIds.Forgotpassword, obj.Id);
        }

        private bool CheckValidateEmail(string txtbox_EMAIL_DIALOG)
        {

            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (txtbox_EMAIL_DIALOG.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی  را وارد نمایید." + "</br>";
                result = false;
            }
            else if (!Validation.IsEmail(txtbox_EMAIL_DIALOG.Trim()))
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی را صحیح وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.users.FirstOrDefault(s => s.IsDelete == false && s.IsActive == true
                    && s.Email == txtbox_EMAIL_DIALOG.Trim());
                if (usr == null)
                {
                    Msg += (++i).ToString() + " - " + "کاربری با پست الکترونیکی وارد شده یافت نشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.Forgotpassword, null);
            }

            return result;
        }

        private void login_(string txtUserName, string txtPassword)
        {
            var usr = dc.users.FirstOrDefault(s => s.IsDelete == false && s.IsActive == true
            && s.UserName == txtUserName.Trim() && s.Password == Utility.EncryptedQueryString.GetMD5Hash(txtPassword.Trim()));
            EventLog.Loging("ورود موفق به سیستم", EventTypeIds.VorodNamovafagh, usr.Id);

            Session["USERID"] = usr.Id;
            //Response.Redirect("~/Application/Home");
            // RedirectToAction("CalenderTimeSheet", "Application");
            //Response.Redirect("~/Application/Pages/TimeSheet/CalenderTimeSheet.aspx");
        }

        private bool CheckValidate(string txtUserName, string txtPassword)
        {

            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (txtUserName.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtPassword == "")
            {
                Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.users.FirstOrDefault(s => s.IsDelete == false && s.IsActive == true
                    && s.UserName == txtUserName.Trim());
                if (usr == null || usr.Password != Utility.EncryptedQueryString.GetMD5Hash(txtPassword))
                {
                    Msg += (++i).ToString() + " - " + "نام کاربری یا رمز عبور شما نادرست می باشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                ViewBag.MessageDialogInfo = MODELDIALOGController.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.VorodNamovafagh, null);
            }

            return result;
        }

    }
}