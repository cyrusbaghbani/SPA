﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_AVASPA.Controllers
{
    public class MODELDIALOGController : Controller
    {
        // GET: MODELDIALOG
        public ActionResult Index()
        {
            
            return View();
        }

        internal static string ShowErrorMessage(string Msg)
        {
            return "ShowErrorMessage('" + Msg + "');";
        }

        internal static string ShowSeccessMessage(string Msg)
        {
            return "ShowSeccessMessage('" + Msg + "');";
        }
    }
}