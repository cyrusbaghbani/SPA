﻿using MVC_AVASPA.Models;
using MVC_AVASPA.Models.Application.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace MVC_AVASPA.Controllers
{
    public class PersonelController : MasterController
    {
        protected string OldPageIndex
        {
            get
            {
                if (Request.Cookies["Searchuasers"] != null && Request.Cookies["Searchuasers"]["PageIndex"] != null)
                {

                    return Request.Cookies["Searchuasers"]["PageIndex"];
                }

                return "";
            }
            set
            {
                Response.Cookies["Searchuasers"]["PageIndex"] = value.ToString();
            }
        }
        private PersonelsModel SetOldParametr()
        {
            PersonelsModel obj = new PersonelsModel(CurrentUser);
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtFullName = FieldFullName;
                    obj.txtMobile = FieldMobileNumber;
                    obj.hfContent = Fieldhfvalue;
                    obj.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(PersonelsModel obj)
        {
            FieldFullName = obj.txtFullName.Trim();
            FieldMobileNumber = obj.txtMobile.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.pageIndex;
            obj.Search();
        }
        // GET: Personel
        public ActionResult Personel()
        {
            PersonelsModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Personel", obj);
        }



        [HttpPost]
        public ActionResult Personel(string btn, FormCollection frm)
        {
            PersonelsModel obj = new PersonelsModel(CurrentUser, frm);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.Remove_User();
                ViewBag.MessageDialogInfo = obj.MessageInfo;
            }
            else if (btn == "NEW")
            {
                return GoToPage("PersonelSpec", "Personel");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("PersonelSpec", "Personel", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Personel", obj);

        }




        public ActionResult PersonelSpec()
        {

            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            var obj = new PersonelSpecModel(CurrentUser, ID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("PersonelSpec", obj);
        }
        [HttpPost]
        public ActionResult PersonelSpec(string btn, FormCollection frm)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            var obj = new PersonelSpecModel(CurrentUser, ID, frm);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    ViewBag.MessageDialogInfo = obj.MessageInfo;
                    return GoToPage("Personel", "Personel", "index=old");
                }
                else
                {
                    ViewBag.MessageDialogInfo = obj.MessageInfo;
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Personel", "Personel", "index=old");
            }
            return View("PersonelSpec", obj);
        }
    }
}