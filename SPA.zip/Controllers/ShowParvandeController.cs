﻿using MVC_AVASPA.Models;
using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace MVC_AVASPA.Controllers
{
    public class ShowParvandeController : MasterController
    {

        [HttpPost]
        public JsonResult SearchTimeSheet(string Value, string PageIndex)
        {

            if (Value != null && Value.Trim() != "")
                Value = EncryptedQueryString.Decrypt(Value.Trim());


            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();

            var q = (from p in dc.Nobats
                     where
                     p.IsDeleted == false
                     &&
                    (
                   p.CostomerId.ToString() == Value
                    )
                     select new
                     {
                         p.UID,
                         p.DateNobat,
                         time = p.TimeNobat + " الی " + p.TimeNobatEnd,
                         p.TimeNobat,
                         vaziatanjamshode = p.VaziatNobat == VaziatNobatType.DONE_ ? "انجام شد" : "-",
                         khadamat = p.NobatTypes.Select(s => s.ServiceType.Name),
                         userFullName = p.user.FullName
                     }).OrderByDescending(s => s.DateNobat).ThenByDescending(s => s.time).ToList();


            GridPageNumber GridPaging = new Models.Controll.GridPageNumber();
            GridPaging.Columns = 7;
            GridPaging.RowRecord = 7;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.currentPage = GridPaging.SetcountGrid(int.Parse("0" + PageIndex));
            GridPaging.IsShowPageNumbering = GridPaging.CountAllRecord > GridPaging.RowRecord;
            GridPaging.maxPageNumber = GridPaging.CountAllRecord % GridPaging.RowRecord == 0 ? ((GridPaging.CountAllRecord / GridPaging.RowRecord)) : ((GridPaging.CountAllRecord / GridPaging.RowRecord) + 1);
            GridPaging.RowRecord = GridPaging.IsShowPageNumbering ? GridPaging.RowRecord : 0;
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q.ToList();

            string str = GetTabelHeader() + " <tbody> <tr> <td data-title=\"\" style=\"font-size:20px\"  colspan=\"" + GridPaging.Columns + "\" > هیچ رکوردی یافت نشد. </td>  </tr> </tbody> ";
            if (list.Any())
            {
                str = GetTabelHeader() + " <tbody> ";
                int linnumbere = GridPaging.StartLineNumber-1;
                foreach (var p in list)
                {
                    str += " <tr> "
                         + " <td data-title=\"ردیف\"  align=\"center\"> " + (++linnumbere).ToString() + " </td> "
                         + " <td data-title=\"روز\"> " + DateShamsi.GetShamsiDayOfWeek(DateShamsi.ConvertShamsiToMiladiDateTime(p.DateNobat).Value.DayOfWeek) + " </td> "
                         + " <td data-title=\"تاریخ\"> " + "" + (p.DateNobat) + " </td> "
                         + " <td data-title=\"زمان\"> " + p.time + " </td> "
                         + " <td  data-title=\"وضعیت\"> " + "" + (p.vaziatanjamshode) + " </td> "
                         + " <td  data-title=\"خدمات\"> " + "" + (p.khadamat.Any() ? p.khadamat.Aggregate((a, b) => a + " ," + b) : "-") + " </td> "
                         + " <td  data-title=\"پرسنل\"> " + "" + (p.userFullName) + " </td> "
                         + "   </tr> ";
                }
                str += " </tbody> ";
                str += GetTableFooter(GridPaging, Value);

            }

            return Json(str);
        }

        private string GetTableFooter(GridPageNumber GridPaging, string cusid)
        {
            string strhtml = "";
            if (GridPaging.IsShowPageNumbering)
            {
                strhtml += " <tr style=\"background-color: #cbd1c2; border: 1px solid #a9a9a9\"> ";

                strhtml += "  <td style=\"right:0;padding-right:5px;font-size:16px\" colspan=\"" + GridPaging.Columns.ToString() + "\" > ";
                if (GridPaging.currentPage >= GridPaging.PageNumber)
                {

                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
                    strhtml += " name=\"pageIndex\" type=\"submit\"  onclick=\"ShowParvande('ModelDialog_Parvande','" + (GridPaging.StartPageNumber - 1) + "');return false;\" value =\"" + (GridPaging.StartPageNumber - 1) + "\" > ";
                    strhtml += " " + GridPaging.Prview + " ";
                    strhtml += " </button> ";
                }

                for (int i = GridPaging.StartPageNumber; i < (GridPaging.EndPageNumber); i++)
                {
                    if (i == GridPaging.currentPage)
                    {

                        strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += "name= \"pageIndex\"  onclick=\"ShowParvande('ModelDialog_Parvande','" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                    else
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += " name=\"pageIndex\"  onclick=\"ShowParvande('ModelDialog_Parvande','" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                }

                if (((GridPaging.maxPageNumber - 1) / GridPaging.PageNumber) > ((GridPaging.currentPage) / GridPaging.PageNumber))
                {
                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex\" ";
                    strhtml += " type=\"submit\" onclick=\"ShowParvande('ModelDialog_Parvande','" + GridPaging.EndPageNumber + "');return false;\" value=\"" + GridPaging.EndPageNumber + "\" > ";
                    strhtml += " " + GridPaging.Next + " ";
                    strhtml += " </button> ";

                }

                strhtml += "  </td> ";

                strhtml += " </tr> ";

            }

            return strhtml;
        }



        private string GetTabelHeader()
        {
            string str = "";
            str += " <thead  class=\"cf\" style=\"background-color: #99b177; border: 1px solid #a9a9a9\"> "
            + " <tr> "
            + " <th style =\"text-align: center;\"> ردیف </th> "
            + " <th style=\"text-align: right;\">روز</th> "
            + " <th style=\"text-align: right;\"> تاریخ </th> "
            + " <th style=\"text-align: right;\">زمان</th> "
            + " <th style=\"text-align: right;\"> وضعیت </th> "
            + " <th style=\"text-align: right;\">خدمات</th> "
            + " <th style=\"text-align: right;\"> پرسنل </th> "
            + " </tr> "
            + " </thead> ";
            return str;
        }



        // GET: ShowParvande
        public ActionResult ShowParvande()
        {
            return View("ShowParvande");
        }
    }
}
