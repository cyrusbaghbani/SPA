﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class CalenderTimeSheetModel
    {
        public string lbl_Title_Month_Year = "";
        public string TBODY_Table_Calender = "";
        public string hfServiceTypeContent = "1";
        public string cbopersonelSelect = "";
        public List<user> lstpersonel = new List<user>();
        public string personIds
        {
            get
            {
                return Utility.EncryptedQueryString.Decrypt(cbopersonelSelect);
            }
        }
        public Security security;
        public CalenderTimeSheetModel(user currentuser)
        {
            security = new Security(currentuser, "timesheet");
        }
    }
}