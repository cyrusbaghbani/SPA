﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class CustomerSpecModel
    {
        public string Id = "";
        public string TelCode = "";
        public string Tel = "";
        public string Name = "";
        public string Mobile = "";
        public string IsSexWoman = "true";
        public string IsSendSMS = "true";
        public string IsAddCoustomerWithUnUniqeMobileNumber = "false";
        public string Family = "";
        public string Dsc = "";
        public string ShowAddCoustomerAllowMobileNumber = "none";
        public string ShowParvandeBimar = "false";
        public string hfIdOfCustomer
        {
            get
            {
                return Id;
            }
        }
        public Security security;
        public CustomerSpecModel(user currentuser)
        {
            security = new Security(currentuser, "customers");
        }
    }
}