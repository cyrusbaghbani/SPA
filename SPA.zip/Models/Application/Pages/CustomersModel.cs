﻿using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class CustomersModel
    {
       
        public string txtFullName = "";
        public string txtMobile = "";
        public string hfContent = "1";
        public string HtmlTBODY_Table = "";
        public string CountSearchRow = "0";
        public string pageIndex = "0";
        
        public GridPageNumber GridPaging = new GridPageNumber();

        public List<Costomer> ListGried = new List<Costomer>();
        public Security security;
        public CustomersModel(user currentuser)
        {
            security = new Security(currentuser, "customers");
        }

    }
}