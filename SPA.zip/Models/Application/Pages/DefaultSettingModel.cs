﻿using MVC_AVASPA.App_Start.Utility;
using MVC_AVASPA.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class ServiceTypeTemp
    {
        public string ID = "";
        public string Priority = "";
        public string Name = "";
        public string ParentName = "";
        public bool IsParent;
        public bool HasChild;
        public string PARENTTID = "";
    }
    public class DefaultSettingModel
    {
        dbAvaSpaDataContext dc = new dbAvaSpaDataContext();

        public string Message = "";
        public string hf_ServiceID = "";
        public string txtName = "";
        public string txtprioroty = "";
        public user CurrentUser = null;
        public string cboServiceType = "";
        public Security security;

        public List<ServiceTypeTemp> lst = new List<ServiceTypeTemp>();

        public DefaultSettingModel(user curentuser)
        {
            CurrentUser = curentuser;
            security = new Security(CurrentUser, "setting");
        }
        public DefaultSettingModel(FormCollection frm, user curentuser)
        {
            hf_ServiceID = Utility.EncryptedQueryString.Decrypt(frm["hf_ServiceID"].ToString().Trim());
            txtName = frm["txtName"].ToString().Trim();
            txtprioroty = frm["txtprioroty"].ToString().Trim();
            cboServiceType = frm["cboServiceType"].ToString().Trim();
            cboServiceType = (cboServiceType == "" || cboServiceType == "PARENT") ? cboServiceType : Utility.EncryptedQueryString.Decrypt(cboServiceType);
            CurrentUser = curentuser;
            security = new Security(CurrentUser, "setting");
        }

        public void BindServiceType()
        {
            lst = new List<ServiceTypeTemp>();
            var q = (from p in dc.ServiceTypes
                     where
                     p.IsDeleted == false
                     select new
                     {
                         p.Id,
                         Priority = p.Priority,
                         ParentPriority = p.ParentId == null ? p.Priority : p.ServiceTypeParent.Priority,
                         p.Name,
                         ParentNamePriority = p.ParentId != null ? p.ServiceTypeParent.Name : p.Name,
                         ParentName = p.ParentId != null ? p.ServiceTypeParent.Name : "-",
                         IsParent = p.ParentId == null,
                         HasChild = p.ServiceTypesChild.Any(s => s.IsDeleted == false),
                         PARENTTID_ = p.ParentId == null ? "PARENT" : p.ParentId.ToString(),
                     }).OrderBy(s => s.ParentPriority).ThenBy(s => s.ParentNamePriority).ThenBy(s => s.IsParent == false).ThenBy(s => s.Priority).ThenBy(s => s.Name).ToList();

            foreach (var p in q)
            {
                lst.Add(new ServiceTypeTemp
                {
                    ID = Utility.EncryptedQueryString.Encrypt(p.Id.ToString()),
                    HasChild = p.HasChild,
                    IsParent = p.IsParent,
                    Name = p.Name,
                    ParentName = p.ParentName,
                    Priority = p.Priority == null ? "" : p.Priority.ToString(),
                    PARENTTID = p.IsParent ? p.PARENTTID_ : Utility.EncryptedQueryString.Encrypt(p.PARENTTID_),
                });
            }
        }
        public void DeleteRowsServiceType()
        {
            if (!security.IsDelete)
            {
                Message = MODELDIALOGController.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید.");
                return;
            }
            var obj = dc.ServiceTypes.SingleOrDefault(s => s.Id.ToString() == hf_ServiceID);
            if (obj == null || obj.IsDeleted == true)
            {
                Message = MODELDIALOGController.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.ServiceTypesChild.Any(s => s.IsDeleted == false) || obj.UserServices.Any(s => s.IsDeleted == false))
            {
                Message = MODELDIALOGController.ShowErrorMessage("به دلیل اطلاعات وابسطه امکان حذف این سطر مقدور نمی باشد");
                return;
            }

            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            Message = MODELDIALOGController.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" خدمت با عنوان '" + obj.Name + "' " + (obj.ParentId == null ? "" : ("زیر مجموعه خدمت '" + obj.ServiceTypeParent.Name + "'")) + " حذف گردید.", EventTypeIds.DELETE, CurrentUser.Id);
        }
        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;
            if (!security.IsSave)
            {
                Message = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره را ندارید.");
                return false;
            }
            if (cboServiceType.Trim() == "")
            {
                Msg += (i++) + " - " + "نوع خدمت را وارد نمایید." + "</br>";
                result = false;
            }
            else if (cboServiceType != "PARENT" && !dc.ServiceTypes.Any(s => s.IsDeleted == false && s.Id.ToString() == cboServiceType))
            {
                Msg += (i++) + " - " + "نوع خدمت انتخاب شده یافت نشد." + "</br>";
                result = false;
            }
            else
            {
                var obj = dc.ServiceTypes.FirstOrDefault(s => s.IsDeleted == false && s.Id.ToString() == hf_ServiceID);
                if (obj != null && obj.ServiceTypesChild.Any(s => s.IsDeleted == false) && cboServiceType != "PARENT")
                {
                    Msg += (i++) + " - " + "خدمت انتخاب شده دارای زیر مجموعه می باشد به همین دلیل نوع خدمت می بایست \"خدمات اصلی\" انتخاب شود." + "</br>";
                    result = false;
                }
                else if (obj != null && cboServiceType == obj.Id.ToString())
                {
                    Msg += (i++) + " - " + "خدمت انتخاب شده نمی تواند زیر مجموعه خودش شود." + "</br>";
                    result = false;
                }
            }
            if (txtName.Trim() == "")
            {
                Msg += (i++) + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
            }


            if (!result)
                Message = MODELDIALOGController.ShowErrorMessage(Msg);
            return result;
        }
        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.ServiceTypes.SingleOrDefault(s => s.Id.ToString() == hf_ServiceID);
            if (obj == null)
            {
                obj = new ServiceType();
                obj.Id = dc.ServiceTypes.Any() == false ? 1 : (dc.ServiceTypes.Count() + 1);

                obj.IsDeleted = false;
                dc.ServiceTypes.InsertOnSubmit(obj);
                IsEdit = false;
            }
            int tmp = 0;
            var servicetypetemp = dc.ServiceTypes.FirstOrDefault(s => s.IsDeleted == false && s.Id.ToString() == cboServiceType);
            obj.ServiceTypeParent = servicetypetemp;
            obj.Name = txtName.Trim();
            obj.Priority = int.TryParse(txtprioroty.Trim(), out tmp) == false ? ((int?)null) : tmp;
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            Message = MODELDIALOGController.ShowSeccessMessage("اطلاعات با موفقیت ذخیره گردید.");

            if (IsEdit == false)
                EventLog.Loging(" خدمت با عنوان '" + obj.Name + "' درج گردید.", EventTypeIds.SAVE, CurrentUser.Id);
            else if (IsEdit == true && Ischange)
                EventLog.Loging(" خدمت با عنوان '" + obj.Name + "' ویرایش گردید.", EventTypeIds.EDIT, CurrentUser.Id);

        }
    }
}