﻿using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class PasswordModal
    {

        public Security security;
        public PasswordModal(user cur)
        {
            security = new Models.Security(cur, "password");
        }

    }
}