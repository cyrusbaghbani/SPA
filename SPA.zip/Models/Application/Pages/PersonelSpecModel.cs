﻿using MVC_AVASPA.App_Start.Utility;
using MVC_AVASPA.Controllers;
using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class PersonelSpecModel
    {
        dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
        public user CurrentUser;
        public string MessageInfo = "";

        public string ID = "";
        public string IsSexWoman = "true";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtDSC = "";
        public string cboRoleSelect = "";

        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public string hfINFOContent = "1";
        public string hfSERVICETypeContent = "1";
        public string hfUserContent = "1";

        public string IsActive = "true";
        public string txtUSERName = "";
        public string txtpass = "";
        public string txtRePass = "";

        public Security security ;

        public List<Role> lstRole = new List<Role>();
        public List<CCheckbox> ListcheckBox = new List<CCheckbox>();


        private void BindListService()
        {

            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
            List<int> lstcheck = new List<int>();
            if (obj != null)
                lstcheck = obj.UserServices.Where(s => s.IsDeleted == false).Select(s => s.ServiceTypeId).ToList();
            var q = (from p in dc.ServiceTypes
                     where
                    (
                     p.IsDeleted == false
                     &&
                     (
                     p.ParentId != null
                     ||
                     (
                     p.ParentId == null
                     &&
                     p.ServiceTypesChild.Any(s => s.IsDeleted == false)
                     )
                     )
                     )
                     ||
                     lstcheck.Contains(p.Id)
                     select new
                     {
                         p.Id,
                         p.Name,
                         p.ParentId,
                         p.Priority
                     }).ToList();

            foreach (var p in q.OrderBy(s => s.Priority).ThenBy(s => s.Name).ToList())
            {
                ListcheckBox.Add(new CCheckbox { Id = Utility.EncryptedQueryString.Encrypt(p.Id.ToString()), Name = p.Name, ParentIds = p.ParentId == null ? "" : Utility.EncryptedQueryString.Encrypt(p.ParentId.ToString()) });
            }
        }
        private void BindRole()
        {
            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
            int? obj_RoleID = obj == null ? (int?)null : obj.RoleId;

            lstRole = dc.Roles.Where(s => s.IsShow == true || s.Id == obj_RoleID).OrderBy(s => s.priority).ThenBy(s => s.Name).ToList();
        }
        private void DisplayPersonel()
        {
            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
                return;
            txtDSC = obj.DSC;
            IsSexWoman = obj.IsSexWoman.ToString().ToLower();
            txtName = obj.Name;
            txtFamily = obj.Family;
            txtMobile = obj.Mobile;
            txtTel = obj.Tel;
            cboRoleSelect = Utility.EncryptedQueryString.Encrypt(obj.RoleId.ToString());
            txtTelCode = obj.TelCode;
            txtAddress = obj.Address;
            txtEmail = obj.Email;
            IsActive = obj.IsActive.ToString().Trim().ToLower();
            txtUSERName = obj.UserName;

            foreach (var item in obj.UserServices.Where(s => s.IsDeleted == false))
            {
                string ser_id = Utility.EncryptedQueryString.Encrypt(item.ServiceTypeId.ToString());
                if (ListcheckBox.FirstOrDefault(s => s.Id == ser_id) != null)
                    ListcheckBox.FirstOrDefault(s => s.Id == ser_id).Value = "true";
            }
        }
        private void BindPersonelSpecModelWithForm(FormCollection form)
        {
            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
            IsSexWoman = form["CboSex"].ToString().Trim();
            txtName = form["txtName"].ToString().Trim();
            txtFamily = form["txtFamily"].ToString().Trim();
            txtMobile = form["txtMobile"].ToString().Trim();
            txtTel = form["txtTel"].ToString().Trim();
            txtDSC = form["txtDSC"].ToString().Trim();
            cboRoleSelect = form["CboRole"].ToString().Trim();

            txtTelCode = form["txtTelCode"].ToString().Trim();
            txtAddress = form["txtAddress"].ToString().Trim();
            txtEmail = form["txtEmail"].ToString().Trim();
            hfINFOContent = form["hfINFOContent"].ToString().Trim();
            hfSERVICETypeContent = form["hfSERVICETypeContent"].ToString().Trim();
            hfUserContent = form["hfUserContent"].ToString().Trim();

            IsActive = form["CboActive"].ToString().Trim().ToLower();
            txtUSERName = form["txtUSERName"] == null ? (obj == null ? "" : obj.UserName) : form["txtUSERName"].ToString().Trim();
            txtpass = form["txtpass"] == null ? "" : form["txtpass"].ToString();
            txtRePass = form["txtRePass"] == null ? "" : form["txtRePass"].ToString();


            List<string> lstcheck = form.AllKeys.Where(s => s.StartsWith("ListcheckBox")).ToList();

            foreach (string item in lstcheck)
            {
                string IDItem = item.Substring("ListcheckBox".Length).ToString();
                if (ListcheckBox.FirstOrDefault(s => s.Id == IDItem) != null)
                    ListcheckBox.FirstOrDefault(s => s.Id == IDItem).Value = "true";
                else
                {
                    string IDVAlue = EncryptedQueryString.Decrypt(IDItem);
                    var it = dc.ServiceTypes.FirstOrDefault(s => s.Id.ToString() == IDVAlue);
                    if (it != null)
                    {
                        ListcheckBox.Add(new CCheckbox { Id = IDItem, Name = it.Name, Value = "true", ParentIds = (it.ParentId == null ? "" : EncryptedQueryString.Decrypt(it.ParentId.ToString())) });
                    }
                }

            }

        }

        public PersonelSpecModel(user usr, string ID_)
        {
            ID = ID_ == null ? "" : ID_.Trim();
            CurrentUser = usr;
            security = new Security(CurrentUser, "personal");
            BindListService();
            BindRole();
            DisplayPersonel();
        }

        public PersonelSpecModel(user usr, string ID_, FormCollection form)
        {
            ID = ID_ == null ? "" : ID_.Trim();
            CurrentUser = usr;
            security = new Security(CurrentUser, "personal");
            BindListService();
            BindRole();
            BindPersonelSpecModelWithForm(form);
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if(!security.IsSave)
            {
                MessageInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            var roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            if (!dc.Roles.Any(s => s.Id.ToString() == roleid))
            {
                Msg += (i++).ToString() + " - " + "سطح دسترسی را انتخاب نمایید" + "</br>";
                result = false;
            }
            if (txtName == "")
            {
                Msg += (i++).ToString() + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtFamily == "")
            {
                Msg += (i++).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtMobile.Trim() != "")
            {
                if (txtMobile.Trim().Count() != 10)
                {
                    Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                    result = false;

                }
            }
            if (txtEmail.Trim() != "")
            {
                if (!Validation.IsEmail(txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                    result = false;
                }
                else if (dc.users.Any(S => S.Id.ToString() != ID && S.IsDelete == false && S.Email == txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }



            if (IsActive == "true")
            {
                if (txtUSERName == "")
                {
                    Msg += (i++).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                    result = false;
                }
                else
                {
                    if (dc.users.Any(s => s.Id.ToString() != ID && s.IsDelete == false && s.IsActive == true && s.UserName == txtUSERName))
                    {
                        Msg += (i++).ToString() + " - " + "نام کاربری در سیستم باید یکتا باشد." + "</br>";
                        result = false;
                    }
                }
                var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
                if (obj == null || obj.Password == null || obj.Password == "")
                {
                    if (txtpass == "")
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtRePass == "")
                    {
                        Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                        result = false;
                    }
                }
                else
                {
                    if (txtpass == "" && txtRePass != "")
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass == "")
                    {
                        Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                        result = false;
                    }
                }
            }
            if (IsActive == "false")
            {
                if (ID == CurrentUser.Id.ToString())
                {
                    Msg += (i++).ToString() + " - " + "اجازه غیر فعال کردن نام کاربری خود را ندارید." + "</br>";
                    result = false;
                }
            }

            if (!result)
                MessageInfo = MODELDIALOGController.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {
                obj = new user();
                obj.Id = (dc.users.Any() ? (dc.users.Max(s => s.Id) + 1) : 1);
                obj.IsDelete = false;
                obj.Password = "";
                obj.UserName = "";
                dc.users.InsertOnSubmit(obj);
                IsEdit = false;
            }

            obj.IsSexWoman = IsSexWoman == "true";
            obj.Name = txtName;
            obj.Family = txtFamily;
            obj.Mobile = txtMobile;
            obj.Tel = txtTel;
            obj.DSC = txtDSC;
            string roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            obj.Role = dc.Roles.First(s => s.Id.ToString() == roleid);

            obj.TelCode = txtTelCode;
            obj.Address = txtAddress;
            obj.Email = txtEmail;


            obj.IsActive = IsActive == "true";
            if (obj.IsActive)
            {
                obj.UserName = txtUSERName;
                if (txtpass != "")
                    obj.Password = Utility.EncryptedQueryString.GetMD5Hash(txtpass);

            }


            var lstolduserservice = dc.UserServices.Where(s => s.userId == obj.Id);
            foreach (var o in lstolduserservice)
            {
                o.IsDeleted = true;
            }
            foreach (var o in ListcheckBox.Where(s => s.Value == "true"))
            {
                string id_ = Utility.EncryptedQueryString.Decrypt(o.Id);
                var userserviceObj = lstolduserservice.FirstOrDefault(s => s.ServiceTypeId.ToString() == id_);
                if (userserviceObj == null)
                {
                    var servicytpe = dc.ServiceTypes.FirstOrDefault(s => s.Id.ToString() == id_);
                    if (servicytpe != null)
                    {
                        userserviceObj = new UserService();
                        userserviceObj.user = obj;
                        userserviceObj.ServiceType = servicytpe;
                        userserviceObj.UID = Guid.NewGuid();
                        userserviceObj.IsDeleted = false;
                        dc.UserServices.InsertOnSubmit(userserviceObj);

                    }
                }
                else
                    userserviceObj.IsDeleted = false;
            }

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' درج گردید.", EventTypeIds.SAVE, CurrentUser.Id);
            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' ویرایش گردید.", EventTypeIds.EDIT, CurrentUser.Id);
            }
            MessageInfo = MODELDIALOGController.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }



    }
}