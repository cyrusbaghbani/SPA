﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_AVASPA.Models;
using System.Web.Mvc;
using MVC_AVASPA.Controllers;
using MVC_AVASPA.App_Start.Utility;
using MVC_AVASPA.Models.Controll;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class PersonelsDataGrid
    {
        public string NumLine = "";
        public string name = "";
        public string Id = "";
        public string Family = "";
        public string Role = "";
        public string Mobile = "";
        public string VaziatNamKarbari = "";
    }
    public class PersonelsModel
    {
        private dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
        private user CurrentUser;
        public string txtFullName = "";
        public string hfContent = "1";
        public string txtMobile = "";
        public string hf_SelectValueID = "";
        public int CountSearchRow = 0;
        public string pageIndex = "0";
        public string MessageInfo = "";
        public GridPageNumber GridPaging = new GridPageNumber();
        public Security security;

        public List<PersonelsDataGrid> lstusr = new List<PersonelsDataGrid>();

        public PersonelsModel(user usr)
        {
            CurrentUser = usr;
            security = new Security(CurrentUser, "personal");

        }
        public PersonelsModel(user usr, FormCollection form)
        {
            CurrentUser = usr;
            security = new Security(CurrentUser, "personal");
            hfContent = form["hfContent"].ToString().Trim();
            txtFullName = form["txtFullName"].ToString().Trim();
            txtMobile = form["txtMobile"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(form["hf_SelectValueID"].ToString().Trim());
            pageIndex = form["pageIndex"] == null ? form["hfCurrentPageIndex"].ToString().Trim() : (form["pageIndex"].ToString().Trim());
        }
        public void Search()
        {
            lstusr = new List<PersonelsDataGrid>();
            int count_grid = int.TryParse("0" + pageIndex, out count_grid) ? count_grid : 0;


            var q1 = (from p in dc.users
                      where
                      p.IsDelete == false
                      &&
                      p.Role.IsShow == true
                      &&
                      (
                            (txtFullName.Trim() == ""
                            ||
                            p.FullName.Contains(txtFullName.Trim()))
                            &&
                            (txtMobile.Trim() == ""
                            ||
                            ("0" + p.Mobile).Contains(txtMobile.Trim()))
                      )
                      select new
                      {
                          p.Id,
                          p.Name,
                          p.Family,
                          p.IsActive,
                          p.Mobile,
                          role = p.Role.Name
                      }).OrderBy(s => s.Name).ThenBy(s => s.Family);


            GridPaging.Columns = security.IsDelete ? 8 : 7;
            GridPaging.CountAllRecord = q1.Count();
            GridPaging.currentPage = GridPaging.SetcountGrid(count_grid);
            GridPaging.IsShowPageNumbering = GridPaging.CountAllRecord > GridPaging.RowRecord;
            GridPaging.maxPageNumber = GridPaging.CountAllRecord % GridPaging.RowRecord == 0 ? ((GridPaging.CountAllRecord / GridPaging.RowRecord)) : ((GridPaging.CountAllRecord / GridPaging.RowRecord) + 1);
            GridPaging.RowRecord = GridPaging.IsShowPageNumbering ? GridPaging.RowRecord : 0;
            var query_ = GridPaging.IsShowPageNumbering ? q1.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q1.ToList();

            CountSearchRow = GridPaging.CountAllRecord;



            int Linenumber = (GridPaging.currentPage * GridPaging.RowRecord);
            foreach (var item in query_)
            {
                lstusr.Add(new PersonelsDataGrid()
                {
                    NumLine = (++Linenumber).ToString(),
                    Id = Utility.EncryptedQueryString.Encrypt(item.Id.ToString()),
                    Family = item.Family,
                    name = item.Name,
                    Mobile = (item.Mobile == null || item.Mobile.Trim() == "") ? "-" : ("0" + item.Mobile),
                    Role = item.role,
                    VaziatNamKarbari = item.IsActive == true ? "فعال" : "-",

                });
            }

        }

        public void Remove_User()
        {
            if (!security.IsDelete)
            {
                MessageInfo = MODELDIALOGController.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.users.SingleOrDefault(s => s.Id.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDelete == true)
            {
                MessageInfo = MODELDIALOGController.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.Id == CurrentUser.Id)
            {
                MessageInfo = MODELDIALOGController.ShowErrorMessage("امکان حذف کاربری خود را ندارید");
                return;
            }

            obj.IsDelete = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            MessageInfo = MODELDIALOGController.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' حذف گردید.", EventTypeIds.DELETE, CurrentUser.Id);

        }
    }

}
