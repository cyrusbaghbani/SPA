﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class ProfileModel
    {
        public Security security;
        public string TxtUserName = "";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public ProfileModel(user cur)
        {
            security = new Security(cur, "profile");
        }
    }
}