﻿using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class SMSModel
    {
        public string hfContent = "1";
        public string TBODY_Table = "";
        public int lblcountSMS = 0;
        public string txtDateAz = "";
        public string txtDateTa = "";
        public string txtMobile = "";
        public string txtFullName = "";
        public string pageIndex = "0";
        public GridPageNumber GridPaging = new GridPageNumber();

        public List<MessageSm> lstsms = new List<MessageSm>();
        public Security security;
        public SMSModel(user currentuser)
        {
            security = new Security(currentuser, "sms");
        }
    }
}