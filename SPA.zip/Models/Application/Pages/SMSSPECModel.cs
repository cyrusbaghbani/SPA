﻿using MVC_AVASPA.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_AVASPA.Models.Application.Pages
{
    public class SMSSPECModel
    {
        private dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
        private string ID = "";

        public string Message = "";
        public string txtdate = "";
        public string hfNameOfReciver = "";
        public string hfIdOfReciver = "";
        public string CboSmsype = "SIMPLE_SMS";
        public string txtMsg = "";
        public string txtSearch = "";
        public string IsEditMode = "false";

        public Security security;
        public SMSSPECModel(string ID_, user cr)
        {
            ID = ID_;
            security = new Security(cr, "sms");

            var obj = dc.MessageSms.SingleOrDefault(s => s.UID.ToString() == ID && s.IsDeleted == false);
            if (obj == null)
            {
                return;
            }
            security = new Security(cr, "sms");
            IsEditMode = "true";
            txtdate = obj.DateErsal + " [ " + obj.TimeErsal + " ]";
            hfNameOfReciver = obj.Costomer.FullName + " [ " + obj.Costomer.Mobile + " ]";
            txtMsg = obj.Message;
        }
        public SMSSPECModel(FormCollection form, string ID_, user cr)
        {
            ID = ID_;
            var obj = dc.MessageSms.SingleOrDefault(s => s.UID.ToString() == ID);
            security = new Security(cr, "sms");
            hfNameOfReciver = form["hfNameOfReciver"].ToString();
            hfIdOfReciver = form["hfIdOfReciver"].ToString();
            CboSmsype = form["CboSmsype"] == null ? ("SIMPLE_SMS") : form["CboSmsype"].ToString();
            txtMsg = form["txtMsg"] == null ? (obj.Message) : form["txtMsg"].ToString();
            txtSearch = form["txtSearch"].ToString();
            txtdate = obj == null ? "" : (obj.DateErsal + " [ " + obj.TimeErsal + " ]");
            IsEditMode = obj == null ? "false" : "true";
        }

        public void Send()
        {

            SmsUtility.SendAllSms_ToPannel(hfIdOfReciver.Split(',').Select(s => Utility.EncryptedQueryString.Decrypt(s)).ToList(), txtMsg.Trim(), CboSmsype);
            Message = MODELDIALOGController.ShowSeccessMessage("پیامک ارسال گردید.");
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            if (!security.IsSave)
            {
                Message = MODELDIALOGController.ShowErrorMessage("شما اچازه ارسال پیامک را ندارید ");
                return false;
            }

            if (hfIdOfReciver.Trim() == "")
            {
                Msg += (i++).ToString() + " - " + "حداقل یک گیرنده را انتخاب نمایید." + "</br>";
                result = false;
            }
            if (txtMsg.Trim() == "")
            {
                Msg += (i++).ToString() + " - " + "متن پیامک  را وارد نمایید." + "</br>";
                result = false;
            }

            var obj = dc.MessageSms.SingleOrDefault(s => s.UID.ToString() == ID && s.IsDeleted == false);
            if (obj != null)
            {
                Msg += (i++).ToString() + " - " + "اجازه ارسال پیامک وجود ندارد." + "</br>";
                result = false;
            }


            if (!result)
                Message = MODELDIALOGController.ShowErrorMessage(Msg);
            return result;
        }
    }
}