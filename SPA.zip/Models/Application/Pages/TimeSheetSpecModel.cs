﻿using MVC_AVASPA.App_Start.Utility;
using MVC_AVASPA.Controllers;
using MVC_AVASPA.Models.Controll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace MVC_AVASPA.Models.Application.Pages
{

    public class TimeSheetSpecModel
    {
        private dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
        private string ID;
        private user CurrentUser;
        private void BindListService()
        {
            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);
            List<int> lstcheck = new List<int>();
            if (obj != null)
                lstcheck = obj.NobatTypes.Where(s => s.IsDeleted == false).Select(s => s.ServiceTypeId).ToList();
            var q = (from p in dc.ServiceTypes
                     where
                    (
                     p.IsDeleted == false
                     &&
                     p.UserServices.Any(s => s.userId.ToString() == personids && s.IsDeleted == false)
                     &&
                     p.ParentId != null
                     )
                     ||
                     lstcheck.Contains(p.Id)

                     select new
                     {
                         p.Id,
                         p.Name,
                         ParentId = p.ParentId == null ? "" : p.ParentId.ToString(),
                         p.Priority,
                         ParrentName = p.ParentId == null ? "" : p.ServiceTypeParent.Name,
                     }).ToList();

            foreach (var p in q.OrderBy(s => s.Priority).ThenBy(s => s.Name).ToList())
            {
                ListcheckBox.Add(new CCheckbox { Id = Utility.EncryptedQueryString.Encrypt(p.Id.ToString()), Name = p.Name, ParentIds = p.ParentId, ParrentName = p.ParrentName });
            }
        }

        public string Message;
        public string hfIdOfCustomer = "";
        public string hfNameOfCustomer = "";
        public string txtDate = "";
        public string txtTimeAz = "";
        public string txtTimeTa = "";
        public string btnShowParvande_Display = "display:none";
        public string btnShowSave = "true";
        public string btnShowAnjamShod = "false";
        public string txtSearch = "";
        public string ISEDITMode = "false";
        public string txtDsc = "";
        public string txtPersonal;
        public string personids;
        public Security security;

        public List<CCheckbox> ListcheckBox;
        public TimeSheetSpecModel(user usr, string ID_, string personids_)
        {
            CurrentUser = usr;
            security = new Security(CurrentUser, "timesheet");
            this.ID = ID_;
            personids = personids_;
            var persons = dc.users.SingleOrDefault(s => s.Id.ToString() == personids);
            if (persons == null)
                personids = null;
            else
            {
                txtPersonal = persons.FullName;
            }
            ListcheckBox = new List<CCheckbox>();
            BindListService();
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            if (!security.IsSave)
            {
                Message = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            if (DateShamsi.GetShamsiDateString(txtDate.Trim()) == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ را وارد نمایید" + "</br>";
                result = false;
            }

            var obj = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == EncryptedQueryString.Decrypt(hfIdOfCustomer));
            if (obj == null)
            {
                Msg += (i++).ToString() + " - " + "مشتری را انتخاب نمایید" + "</br>";
                result = false;
            }



            if (!ListcheckBox.Any(s => s.Value == "true"))
            {
                Msg += (i++).ToString() + " - " + "حداقل یک خدمت را انتخاب نمایید" + "</br>";
                result = false;
            }

            string txtAz = DateShamsi.GetShamsiTimeString(txtTimeAz.Trim() + ":00");
            string txtTa = DateShamsi.GetShamsiTimeString(txtTimeTa.Trim() + ":00");
            if ( txtAz== "")
            {
                Msg += (i++).ToString() + " - " + "فیلد \"از زمان\" را صحیح وارد نمایید" + "</br>";
                result = false;
            }
            if (txtTa == "")
            {
                Msg += (i++).ToString() + " - " + "فیلد \"تا زمان\" را صحیح وارد نمایید" + "</br>";
                result = false;
            }
            if(txtTa != ""&& txtAz != "")
            {
                int tamins = int.Parse("0" + txtTa.Split(':')[0]) * 60 + int.Parse("0" + txtTa.Split(':')[1]);
                int azmins = int.Parse("0" + txtAz.Split(':')[0]) * 60 + int.Parse("0" + txtAz.Split(':')[1]);
                if (tamins < azmins)
                {
                    Msg += (i++).ToString() + " - " + "فیلد \"تا زمان\" باید بزرگتر از فیلد  \"از زمان\"  باشد." + "</br>";
                    result = false;
                }
            }


            //var nobat = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);
            //if (nobat != null)
            //{
            //    Msg += (i++).ToString() + " - " + "امکان ذخیره این فیلد وجود ندارد" + "</br>";
            //    result = false;
            //}
            if (!result)
                Message = MODELDIALOGController.ShowErrorMessage(Msg);

            return result;
        }

        public void Save(int currentuserId, bool send_SMS)
        {
            bool IsEdit = true;
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Nobat();
                obj.UID = Guid.NewGuid();
                dc.Nobats.InsertOnSubmit(obj);
                IsEdit = false;
            }
            string customerid = EncryptedQueryString.Decrypt(hfIdOfCustomer);
            var customer = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == customerid);
            obj.Costomer = customer;
            obj.user = dc.users.SingleOrDefault(s => s.Id.ToString() == personids);
            obj.DateNobat = DateShamsi.GetShamsiDateString(txtDate.Trim());
            obj.DateSabt = DateShamsi.GetCurrentDate() + " " + DateShamsi.GetCurrentHour();
            obj.Dsc = txtDsc;
            obj.IsDeleted = false;
            obj.IsRemindeer = obj.Costomer.IsSendSMS;

            obj.TimeNobat = DateShamsi.GetShamsiTimeString(txtTimeAz.Trim() + ":00").Substring(0, 5);
            obj.TimeNobatEnd = DateShamsi.GetShamsiTimeString(txtTimeTa.Trim() + ":00").Substring(0, 5);

            var lstnobattyps = dc.NobatTypes.Where(s => s.NobatId == obj.UID).ToList();
            foreach (var q in lstnobattyps)
                q.IsDeleted = true;

            foreach (CCheckbox item in ListcheckBox)
            {

                if (item.Value == "true")
                {
                    string IDTemp = EncryptedQueryString.Decrypt(item.Id);
                    var nobattype = dc.NobatTypes.FirstOrDefault(s => s.NobatId == obj.UID && s.ServiceTypeId.ToString() == IDTemp);
                    if (nobattype == null)
                    {

                        nobattype = new NobatType();
                        nobattype.UID = Guid.NewGuid();
                        nobattype.IsDeleted = false;
                        nobattype.Nobat = obj;
                        nobattype.ServiceType = dc.ServiceTypes.Single(s => s.Id.ToString() == IDTemp);
                        nobattype.user = dc.users.SingleOrDefault(s => s.Id == CurrentUser.Id);
                        dc.NobatTypes.InsertOnSubmit(nobattype);
                    }
                    else
                        nobattype.IsDeleted = false;

                }
            }


            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging("' نوبت مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName
                                    + "' با تاریخ '" + obj.DateNobat
                                    + "' و ساعت شروع '" + obj.TimeNobat
                                    + " با خدمات '" + (dc.NobatTypes.Any(s => s.NobatId == obj.UID) ? (dc.NobatTypes.Where((s => s.NobatId == obj.UID)).Select(s => s.ServiceType.Name).ToList().Aggregate((a, b) => a + " , " + b)) : "")
                                    + "' مربوط به پرسنل '" + obj.user.FullName
                                    + "' درج گردید.", EventTypeIds.SAVE, currentuserId);
            }
            else if (ischange && IsEdit)
            {
                EventLog.Loging("' نوبت مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName
                    + "' با تاریخ '" + obj.DateNobat
                    + "' و ساعت شروع '" + obj.TimeNobat
                    + " با خدمات '" + (dc.NobatTypes.Any(s => s.NobatId == obj.UID) ? (dc.NobatTypes.Where((s => s.NobatId == obj.UID)).Select(s => s.ServiceType.Name).ToList().Aggregate((a, b) => a + " , " + b)) : "")
                    + "' مربوط به پرسنل '" + obj.user.FullName
                    + "' ویراسش گردید.", EventTypeIds.EDIT, currentuserId);
            }
            Message = MODELDIALOGController.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");
            if (send_SMS)
            {
                string currentdate = DateShamsi.GetCurrentDate();
                string date = obj.DateNobat;
                if (DateShamsi.AddDaysToShamsiDate(currentdate, 0, 0, 2).CompareTo(date) <= 0)//بیش از دو روز با نوبت فاصله دارد پس پیامک بده
                {
                    date = DateShamsi.AddDaysToShamsiDate(date, 0, 0, -1);
                    DateTime? dt = DateShamsi.ConvertShamsiToMiladiDateTime(date);
                    if (dt != null)
                    {
                        dt = dt.Value.AddHours(int.Parse(obj.TimeNobat.Split(':')[0]));
                        dt = dt.Value.AddMinutes(int.Parse(obj.TimeNobat.Split(':')[1]));
                    }
                    string msgbody = (customer.IsSexWoman == null ? "خانم/آقای " : (customer.IsSexWoman == true ? "خانم " : "آقای "))
                        + customer.FullName + " عزیز در تاریخ " + obj.DateNobat + " ساعت " + obj.TimeNobat
                        + " در " + PishfarzSpa.Name + " منتظر شما هستیم." + Environment.NewLine
                        + "با تشکر " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
                    SmsUtility.SimpleSendSingleMessage(customer.Mobile, msgbody, dt, obj.UID, customer.Id);
                    EventLog.Loging("پیام کوتاه '" + msgbody + "' توسط سیستم ارسال گردید.", EventTypeIds.ErsalPayamKotahSystemi, currentuserId);
                }
                ///پیامک همین الان فرستاده شود
                string msgbodyNOW = (customer.IsSexWoman == null ? "خانم/آقای " : (customer.IsSexWoman == true ? "خانم " : "آقای "))
                        + customer.FullName + " عزیز در تاریخ " + obj.DateNobat + " ساعت " + obj.TimeNobat
                        + " در " + PishfarzSpa.Name + " منتظر شما هستیم." + Environment.NewLine
                        + "با تشکر " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
                SmsUtility.SimpleSendSingleMessage(customer.Mobile, msgbodyNOW, null, obj.UID, customer.Id);
                EventLog.Loging("پیام کوتاه '" + msgbodyNOW + "' توسط سیستم ارسال گردید.", EventTypeIds.ErsalPayamKotahSystemi, currentuserId);

            }
            ///ارسال پیامک
        }

        public void SendSmsPayamTashakor(int currentuserId)
        {
            if (!security.IsEdit)
            {
                Message = MODELDIALOGController.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return;
            }
            var obj = dc.Nobats.SingleOrDefault(s => s.UID.ToString() == ID);
            obj.VaziatNobat = VaziatNobatType.DONE_;
            obj.DateAnjamNobat = DateShamsi.GetCurrentDate();
            obj.TimeAnjamNobat = DateShamsi.GetCurrentHour();
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();

            if (ischange)
            {
                EventLog.Loging("' نوبت مشتری با نام و نام خانوادگی '" + obj.Costomer.FullName
                    + "' با تاریخ '" + obj.DateNobat
                    + "' و ساعت شروع '" + obj.TimeNobat
                    + " با خدمات '" + (obj.NobatTypes.Any() ? (obj.NobatTypes.Select(s => s.ServiceType.Name).Aggregate((a, b) => a + " , " + b)) : "")
                    + "' مربوط به پرسنل '" + obj.user.FullName
                    + "' پایان یافت.", EventTypeIds.PayanYaftan, currentuserId);
            }
            Message = MODELDIALOGController.ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید.");
            btnShowAnjamShod = "false";
            if (obj.Costomer.IsSendSMS)
            {
                string msgbody = (obj.Costomer.IsSexWoman == null ? "خانم/آقای " : (obj.Costomer.IsSexWoman == true ? "خانم " : "آقای ")) + obj.Costomer.FullName
            + " از این که " + PishfarzSpa.Name + " را جهت انجام خدمات خود انتخاب نموده اید کمال تشکر را داریم.  " + Environment.NewLine
             + "مدیریت " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
                SmsUtility.SimpleSendSingleMessage(obj.Costomer.Mobile, msgbody, null, obj.UID, obj.CostomerId);
                EventLog.Loging("پیام کوتاه '" + msgbody + "' توسط سیستم ارسال گردید.", EventTypeIds.ErsalPayamKotahSystemi, currentuserId);
            }
        }
    }
}