﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Controll
{
    public class CCheckbox
    {
        public string Id = "";
        public string Name = "";
        public string Value = "false";
        public string ParentIds = "";
        public string ParrentName = "";
    }
}