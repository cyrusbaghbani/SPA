﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models.Controll
{
    public class GridPageNumber
    {
        public int Columns = 0;
        public int currentPage = 0;
        public int maxPageNumber = 0;
        public bool IsShowPageNumbering;
        public int CountAllRecord;
        public int RowRecord = 10;
        public string Next = ">>";
        public string Prview = "<<";
        public int PageNumber = 7;
        public List<string> lst_headerName = new List<string>();

        public int StartLineNumber
        {
            get
            {
                return (currentPage * RowRecord) + 1;
            }
        }
        public int StartPageNumber
        {
            get
            {
                return currentPage % PageNumber == 0 ? currentPage : ((currentPage / PageNumber) * PageNumber);
            }
        }
        public int EndPageNumber
        {
            get
            {
                return StartPageNumber + PageNumber > maxPageNumber ? (maxPageNumber) : (StartPageNumber + PageNumber);
            }
        }
        public int SetcountGrid(int currentPageIndex)
        {
            if (currentPageIndex == 0 || ((currentPageIndex * RowRecord) < CountAllRecord))
            {
                return currentPageIndex;
            }

            else if ((currentPageIndex * RowRecord) > CountAllRecord)
            {
                return CountAllRecord / RowRecord;
            }
            else if ((currentPageIndex * RowRecord) == CountAllRecord)
            {
                int tmp = (CountAllRecord / RowRecord) - 1;
                return tmp > 0 ? tmp : 0;
            }

            return currentPageIndex;
        }
        public string GetHtmlFooter()
        {
            string strhtml = "";
            if (IsShowPageNumbering)
            {
                strhtml += " <tr style=\"background-color: #cbd1c2; border: 1px solid #a9a9a9\"> ";

                strhtml += "  <td style=\"right:0;padding-right:5px;font-size:16px\" colspan=\"" + Columns.ToString() + "\" > ";
                if (currentPage >= PageNumber)
                {

                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
                    strhtml += " name=\"pageIndex\"  type=\"submit\" value =\"" + (StartPageNumber - 1) + "\" > ";
                    strhtml += " " + Prview + " ";
                    strhtml += " </button> ";
                }

                for (int i = StartPageNumber; i < (EndPageNumber); i++)
                {
                    if (i == currentPage)
                    {

                        strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += "name= \"pageIndex\" type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                    else
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
                        strhtml += " name=\"pageIndex\" type=\"submit\" value=" + (i) + " > ";
                        strhtml += " " + (i + 1) + " ";
                        strhtml += " </button> ";
                    }
                }

                if (((maxPageNumber - 1) / PageNumber) > ((currentPage) / PageNumber))
                {
                    strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex\" ";
                    strhtml += " type=\"submit\" value=\"" + EndPageNumber + "\" > ";
                    strhtml += " " + Next + " ";
                    strhtml += " </button> ";

                }

                strhtml += "  </td> ";

                strhtml += " </tr> ";

            }
            strhtml += " <input type = \"hidden\" name=\"hfCurrentPageIndex\" value=\"" + currentPage + "\" /> ";
            return strhtml;
        }
        public string GetHtmlHeader(bool HasRadif = true)
        {
            string html = " <thead class=\"cf\" style=\"background-color: #99b177; border: 1px solid #a9a9a9\"> ";

            html += " <tr> ";
            if (HasRadif)
                html += " <th style=\"text-align: center\">ردیف</th> ";
            foreach (var str in lst_headerName)
                html += " <th style=\"text-align: right\">" + str + "</th> ";

            html += " </tr> ";
            html += " </thead> ";

            return html;

        }
    }
}