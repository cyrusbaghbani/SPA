﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_AVASPA.Models
{
    public class Security
    {
        public bool Is_SHOW_Munu_Personel = false;
        public bool Is_SHOW_Munu_Customers = false;
        public bool Is_SHOW_Munu_TimeSheet = false;
        public bool Is_SHOW_Munu_SMS = false;
        public bool Is_SHOW_Munu_Setting = false;
        public bool Is_SHOW_Munu_Report = false;
        public bool Is_SHOW_Munu_Perofile = false;
        public bool Is_SHOW_Munu_Password = false;


        public bool IsEdit = false;
        public bool IsNew = false;
        public bool IsSave = false;
        public bool IsDelete = false;
        public bool IsDisplay = false;

        public int RoleId = -1;
        public Security(user currentuser, string PageName)
        {
           
            SetMenu(currentuser);
            SetPageAccess(currentuser, PageName);

        }

        private void SetMenu(user currentuser)
        {
            if (currentuser == null || currentuser.IsActive == false || currentuser.IsDelete == true)
                return;
            RoleId = currentuser.RoleId;
            if (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds)
            {
                Is_SHOW_Munu_Personel = true;
                Is_SHOW_Munu_Customers = true;
                Is_SHOW_Munu_TimeSheet = true;
                Is_SHOW_Munu_SMS = true;
                Is_SHOW_Munu_Setting = true;
                Is_SHOW_Munu_Report = true;
                Is_SHOW_Munu_Perofile = true;
                Is_SHOW_Munu_Password = true;
            }
            else if (currentuser.RoleId == RoleIds.MonshiIds)
            {
                Is_SHOW_Munu_Customers = true;
                Is_SHOW_Munu_TimeSheet = true;
                Is_SHOW_Munu_Perofile = true;
                Is_SHOW_Munu_Password = true;
            }
            else if (currentuser.RoleId == RoleIds.PersonelIds)
            {
                Is_SHOW_Munu_TimeSheet = true;
                Is_SHOW_Munu_Perofile = true;
                Is_SHOW_Munu_Password = true;
            }
        }

        private void SetPageAccess(user currentuser, string pageName)
        {
            if (currentuser == null || currentuser.IsActive == false || currentuser.IsDelete == true)
                return;

            if (pageName.ToLower() == "profile" || pageName.ToLower() == "password")
            {
                IsDisplay = true;
                IsEdit = true;
                IsSave = true;
                IsDelete = true;
                IsNew = true;
            }
            else if (pageName.ToLower() == "timesheet")
            {
                IsDisplay = true;
                IsEdit = true;
                IsSave = true;
                IsDelete = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds || currentuser.RoleId == RoleIds.MonshiIds);
                IsNew = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds || currentuser.RoleId == RoleIds.MonshiIds);

            }
            else if (pageName.ToLower() == "customers")
            {
                IsDisplay = currentuser.RoleId != RoleIds.PersonelIds;
                IsEdit = currentuser.RoleId != RoleIds.PersonelIds;
                IsSave = currentuser.RoleId != RoleIds.PersonelIds;
                IsDelete = currentuser.RoleId != RoleIds.PersonelIds;
                IsNew = currentuser.RoleId != RoleIds.PersonelIds;

            }
            else if (pageName.ToLower() == "report"|| pageName.ToLower() == "personal"|| pageName.ToLower() == "sms"|| pageName.ToLower() == "setting")
            {
                IsDisplay = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds);
                IsEdit = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds);
                IsSave = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds);
                IsDelete = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds);
                IsNew = (currentuser.RoleId == RoleIds.Administrator || currentuser.RoleId == RoleIds.AdminWebSiteIds);

            }
        }
    }
}