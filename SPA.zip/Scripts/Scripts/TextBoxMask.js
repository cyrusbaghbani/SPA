﻿
function Remove(str, index) {

    strtemp = "";
    //for (i = 0 ; i<str.length ; i++)
    //{
    //  if (i!=index)
    //  {
    //  strtemp+=str.substr(i,1);
    //  }

    //}
    //return strtemp ;
    return str.substr(0, index);

}
function normalizedate(strdate) {
    var strtemp = strdate;
    var chartemp;
    for (i = 0; i < strdate.length; i++) {
        chartemp = strdate.substr(i, 1);
        switch (i) {

            case 0:
                switch (chartemp) {
                    case "1":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }

                break;
            case 1:
                switch (chartemp) {
                    case "3":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }

                break;
            case 2:

                switch (chartemp) {
                    case "0":
                        strtemp = strtemp;
                        break;

                    case "1":
                        strtemp = strtemp;
                        break;
                    case "2":
                        strtemp = strtemp;
                        break;
                    case "3":
                        strtemp = strtemp;
                        break;
                    case "4":
                        strtemp = strtemp;
                        break;
                    case "5":
                        strtemp = strtemp;
                        break;
                    case "6":
                        strtemp = strtemp;
                        break;

                    case "7":
                        strtemp = strtemp;
                        break;

                    case "8":
                        strtemp = strtemp;
                        break;
                    case "9":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }



                break;
            case 3:
                switch (chartemp) {
                    case "0":
                        strtemp = strtemp;
                        break;
                    case "1":
                        strtemp = strtemp;
                        break;
                    case "2":
                        strtemp = strtemp;
                        break;
                    case "3":
                        strtemp = strtemp;
                        break;
                    case "4":
                        strtemp = strtemp;
                        break;
                    case "5":
                        strtemp = strtemp;
                        break;
                    case "6":
                        strtemp = strtemp;
                        break;
                    case "7":
                        strtemp = strtemp;
                        break;
                    case "8":
                        strtemp = strtemp;
                        break;
                    case "9":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }




                break;
            case 4:
                switch (chartemp) {
                    case "/":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }

                break;

            case 5:
                switch (chartemp) {
                    case "0":
                        strtemp = strtemp;
                        break;
                    case "1":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }
                break;
            case 6:
                switch (chartemp) {
                    case "0":
                        if (strtemp.substr(5, 1) != "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "1":
                        strtemp = strtemp;
                        break;
                    case "2":
                        strtemp = strtemp;
                        break;
                    case "3":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "4":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "5":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "6":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "7":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "8":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "9":
                        if (strtemp.substr(5, 1) == "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }

                        break;
                    default:

                        strtemp = Remove(strtemp, i);
                }

                break;
            case 7:
                switch (chartemp) {
                    case "/":
                        strtemp = strtemp;
                        break;
                    default:
                        strtemp = Remove(strtemp, i);
                }

                break;



            case 8:
                switch (chartemp) {
                    case "0":
                        strtemp = strtemp;
                        break;
                    case "1":
                        strtemp = strtemp;
                        break;
                    case "2":
                        strtemp = strtemp;
                        break;
                    case "3":
                        strtemp = strtemp;
                        break;


                    default:
                        strtemp = Remove(strtemp, i);
                }
                break;
            case 9:
                switch (chartemp) {
                    case "0":
                        if (strtemp.substr(8, 1) != "0") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "1":
                        strtemp = strtemp;
                        break;
                    case "2":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "3":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "4":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "5":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "6":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "7":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "8":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }
                        break;
                    case "9":
                        if (strtemp.substr(8, 1) != "3") {
                            strtemp = strtemp;
                        }
                        else {
                            strtemp = Remove(strtemp, i);
                        }

                        break;
                    default:

                        strtemp = Remove(strtemp, i);
                }

                break;


        }
    }
    return strtemp;
}


function maskdate(textbox) {
    var loc = "4,7";
    var delim = "/";
    var locs = loc.split(',');
    var str = textbox.value;
    for (var i = 0; i <= locs.length; i++) {
        for (var k = 0; k <= str.length; k++) {
            if (k == locs[i]) {
                if (str.substring(k, k + 1) != delim) {
                    if (event.keyCode != 8) { //backspace
                        str = str.substring(0, k) + delim + str.substring(k, str.length);
                    }
                }
            }
        }
    }

    textbox.value = normalizedate(str);

}