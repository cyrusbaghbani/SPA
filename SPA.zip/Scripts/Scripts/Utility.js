﻿function IsNumeric(e) {

    if ([e.keyCode || e.which] == 8) //this is to allow backspace
        return true;
    if ([e.keyCode || e.which] == 13) //this is to allow Enter
        return true;

    if (e.keyCode == 9 || e.which == 0) //this is to allow tab
        return true;

    if ([e.keyCode || e.which] < 48 || [e.keyCode || e.which] > 57)
        e.preventDefault ? e.preventDefault() : e.returnValue = false;

}
